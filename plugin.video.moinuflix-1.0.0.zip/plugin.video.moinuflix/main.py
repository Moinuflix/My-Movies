import sys
import urllib.parse
import json
import ssl
import xbmcgui
import xbmcplugin
import urllib.request

BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1])
REPO_URL = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def fetch_json(file_name):
    url = REPO_URL + file_name
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, context=ctx, timeout=15) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception:
        return []

def main_menu():
    categories = [
        ("🎬 Movies", "data_c01.json", "video"),
        ("📺 Series / TV Shows", "data_c02.json", "video"),
        ("🎵 Music", "data_c03.json", "audio")
    ]
    for name, file_name, media_type in categories:
        url = build_url({"action": "list_items", "file": file_name, "media": media_type})
        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def list_items(file_name, media_type):
    items = fetch_json(file_name)
    for item in items:
        title = item.get("title") or item.get("name") or "Untitled"
        year = item.get("year")
        display_title = f"{title} ({year})" if year else title
        
        stream_url = item.get("stream_url") or item.get("url") or ""
        poster = item.get("poster") or ""
        fanart = item.get("fanart") or ""
        plot = item.get("plot") or ""
        
        li = xbmcgui.ListItem(label=display_title)
        info_dict = {"title": display_title, "plot": plot}
        if year:
            info_dict["year"] = int(year)
        li.setInfo(media_type, info_dict)
        
        art = {}
        if poster:
            art["thumb"] = poster
            art["poster"] = poster
        if fanart:
            art["fanart"] = fanart
        if art:
            li.setArt(art)
            
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=stream_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    action = params.get("action")
    if not action:
        main_menu()
    elif action == "list_items":
        list_items(params.get("file"), params.get("media"))
