# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 0
JSON_URL = "https://moinuflix.github.io/My-Movies/movies.json"

def get_movies():
    try:
        req = urllib.request.Request(
            JSON_URL,
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) Kodi/MoinuFlix"}
        )
        with urllib.request.urlopen(req, timeout=12) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception as e:
        xbmc.log(f"[MoinuFlix] Error loading JSON: {e}", xbmc.LOGERROR)
        return []

def run():
    xbmcplugin.setContent(HANDLE, "movies")
    movies = get_movies()
    
    if not movies:
        dialog = xbmcgui.Dialog()
        dialog.notification("MoinuFlix", "Failed to load movies.json", xbmcgui.NOTIFICATION_ERROR, 4000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for m in movies:
        title = m.get("title", "Unknown")
        stream_url = m.get("url", "")
        if not stream_url:
            continue

        li = xbmcgui.ListItem(label=title)
        
        poster = m.get("poster") or ""
        fanart = m.get("fanart") or poster
        clearlogo = m.get("clearlogo") or ""
        
        art = {
            "thumb": poster,
            "poster": poster,
            "fanart": fanart,
            "clearlogo": clearlogo,
            "icon": poster
        }
        li.setArt(art)

        rating_val = 0.0
        try:
            if m.get("rating") and m.get("rating") not in ["", "N/A"]:
                rating_val = float(m.get("rating"))
        except:
            pass

        year_val = None
        try:
            if m.get("year") and str(m.get("year")).isdigit():
                year_val = int(m.get("year"))
        except:
            pass

        genres = m.get("genre", [])
        genre_str = ", ".join(genres) if isinstance(genres, list) else str(genres)

        trailer = m.get("trailer_kodi") or m.get("trailer_url") or m.get("trailer") or ""

        info = {
            "title": title,
            "plot": m.get("plot", ""),
            "rating": rating_val,
            "year": year_val,
            "genre": genre_str,
            "trailer": trailer,
            "mediatype": "movie"
        }
        li.setInfo("video", info)
        li.setProperty("IsPlayable", "true")
        
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=stream_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    run()
