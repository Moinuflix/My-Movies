# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin

ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1] else 0
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""

REPO_RAW_BASE = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"
USER_AGENT = "Kodi-MoinuTV-PrivatePlayer/1.0"

def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"

def fetch_json_chunk(filename):
    url = f"{REPO_RAW_BASE}{filename}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception as e:
        xbmc.log(f"[MoinuFlix Error] Could not load {filename}: {str(e)}", xbmc.LOGERROR)
        return []

def show_main_menu():
    categories = [
        {"title": "🎬 1. Movies", "mode": "list_movies", "desc": "4K UHD, 1080p FHD & Multi-Audio Movies"},
        {"title": "📺 2. Web Series", "mode": "list_series", "desc": "TV Shows, Seasons & Episode Library"},
        {"title": "🎵 3. 5.1 / Atmos Songs", "mode": "list_songs", "desc": "Dolby Atmos 7.1, 5.1 Surround & FLAC Lossless Music"},
        {"title": "🍿 4. YouTube Vault", "mode": "list_vault", "desc": "Comedy Scenes, Action Moments, 4K Video Songs & Best Scenes"}
    ]
    for cat in categories:
        li = xbmcgui.ListItem(label=cat["title"])
        li.setInfo("video", {"title": cat["title"], "plot": cat["desc"]})
        url = build_url({"mode": cat["mode"]})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_movies():
    movies = fetch_json_chunk("data_c01.json")
    for movie in movies:
        title = movie.get("title", movie.get("name", "Unknown Movie"))
        year = movie.get("year", 0)
        rating = movie.get("rating", 7.0)
        plot = movie.get("plot", "")
        poster = movie.get("poster", "")
        fanart = movie.get("fanart", "")
        versions = movie.get("versions", [])
        li = xbmcgui.ListItem(label=f"{title} ({year})")
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "year": year, "rating": rating, "plot": plot, "mediatype": "movie"})
        if len(versions) > 1:
            url = build_url({"mode": "select_movie_version", "movie_data": json.dumps(movie)})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
        else:
            stream_url = movie.get("stream_url", "")
            if versions and "stream_url" in versions[0]:
                stream_url = versions[0]["stream_url"]
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def select_movie_version(movie_json):
    movie = json.loads(movie_json)
    versions = movie.get("versions", [])
    if not versions: return
    labels = [f"[{v.get("quality","1080p")}] {v.get("resolution","")} • {v.get("audio","")}" for v in versions]
    dialog = xbmcgui.Dialog()
    choice = dialog.select(f"Select Quality — {movie.get("title")}", labels)
    if choice != -1:
        chosen_stream = versions[choice].get("stream_url", "")
        play_item = xbmcgui.ListItem(path=chosen_stream)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, play_item)

def list_series():
    shows = fetch_json_chunk("data_c02.json")
    for show in shows:
        title = show.get("title", "Unknown Series")
        year = show.get("year", 0)
        poster = show.get("poster", "")
        fanart = show.get("fanart", "")
        episodes = show.get("episodes", [])
        ep_count = len(episodes) if episodes else 1
        li = xbmcgui.ListItem(label=f"{title} ({year})")
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "year": year, "plot": f"Total Episodes: {ep_count}\n\n" + show.get("plot", ""), "mediatype": "tvshow"})
        url = build_url({"mode": "list_episodes", "show_data": json.dumps(show)})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.setContent(ADDON_HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(show_json):
    show = json.loads(show_json)
    episodes = show.get("episodes", [])
    poster = show.get("poster", "")
    fanart = show.get("fanart", "")
    for ep in episodes:
        title = ep.get("title", ep.get("name", "Episode"))
        season = ep.get("season", 1)
        episode = ep.get("episode", 1)
        plot = ep.get("plot", "")
        stream_url = ep.get("stream_url", "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "season": season, "episode": episode, "plot": plot, "mediatype": "episode"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "episodes")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_songs():
    songs = fetch_json_chunk("data_c03.json")
    for song in songs:
        title = song.get("title", "Audio Track")
        album = song.get("original_title", "")
        year = song.get("year", 0)
        poster = song.get("poster", "")
        specs = song.get("specs", {})
        audio_name = specs.get("audio", "5.1 Surround")
        stream_url = song.get("stream_url", "")
        li = xbmcgui.ListItem(label=f"🎵 {title} [{audio_name}]")
        li.setArt({"thumb": poster, "poster": poster, "fanart": poster})
        li.setInfo("music", {"title": title, "album": album, "year": year, "comment": song.get("plot", "")})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vault():
    vault_items = fetch_json_chunk("data_c04.json")
    for item in vault_items:
        title = item.get("title", "YouTube Clip")
        category = item.get("category", "Clip")
        thumbnail = item.get("thumbnail", "")
        stream_url = item.get("stream_url", "")
        li = xbmcgui.ListItem(label=f"[{category}] {title}")
        li.setArt({"thumb": thumbnail, "poster": thumbnail, "fanart": thumbnail})
        li.setInfo("video", {"title": title, "genre": category, "mediatype": "video"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get("mode")
    if mode == "list_movies": list_movies()
    elif mode == "select_movie_version": select_movie_version(params.get("movie_data", "{}"))
    elif mode == "list_series": list_series()
    elif mode == "list_episodes": list_episodes(params.get("show_data", "{}"))
    elif mode == "list_songs": list_songs()
    elif mode == "list_vault": list_vault()
    else: show_main_menu()

if __name__ == "__main__":
    router(sys.argv[2][1:] if len(sys.argv) > 2 else "")
