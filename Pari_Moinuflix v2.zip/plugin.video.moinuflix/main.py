# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import re
import xbmc
import xbmcgui
import xbmcplugin

ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
REPO_RAW_BASE = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"
USER_AGENT = "Kodi-MoinuTV-PrivatePlayer/2.0"

# Online Cloudflare Worker Endpoint for Continue Watching & API Sync (Default fallback to raw GitHub chunks)
WORKER_API_BASE = "https://api.moinuflix.workers.dev" 

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def fetch_json(filename):
    url = REPO_RAW_BASE + filename
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception as e:
        xbmc.log("[MoinuFlix] Error loading " + filename + ": " + str(e), xbmc.LOGERROR)
        return []

def get_clean_title(item):
    return item.get("title") or item.get("name") or "Unknown"

def extract_trailer_url(item):
    t = item.get("trailer")
    yt_id = ""
    if isinstance(t, dict):
        raw = t.get("youtube_url") or t.get("url") or ""
    elif isinstance(t, str):
        raw = t
    else:
        raw = ""
    
    if not raw:
        return ""
        
    if "plugin://plugin.video.youtube" in raw:
        return raw

    match = re.search(r"(?:v=|\/|youtu\.be\/)([a-zA-Z0-9_-]{11})", raw)
    if match:
        yt_id = match.group(1)
    elif len(raw.strip()) == 11:
        yt_id = raw.strip()

    if yt_id:
        return f"plugin://plugin.video.youtube/play/?video_id={yt_id}"
    return raw

def detect_collection_name(title, item):
    """Auto-detect franchise name via TMDB collection key or title patterns (Part 1, 2, Franchise)"""
    if item.get("collection"):
        return item.get("collection")
    # Pattern check (e.g. Baahubali: Part 1, KGF Chapter 2, Spider-Man 3)
    clean = re.sub(r"(:?\s*(Part|Chapter|Episode|Vol|Volume)\s*\d+.*|\s+\d+$)", "", title, flags=re.I).strip()
    return clean if clean != title else None

# ==================== MAIN ROOT MENU V2 ====================

def main_menu():
    categories = [
        ("🔍 Search Movies & Shows", "search"),
        ("🎬 Movies (All)", "list_movies"),
        ("📦 Movie Collections / Sets", "list_collections"),
        ("📜 Smart Playlists (Auto-Queue)", "list_playlists"),
        ("📺 Web Series", "list_series"),
        ("🎵 5.1 / Atmos Songs", "list_songs"),
        ("🍿 YouTube Vault", "list_vault"),
        ("🔥 Recently Added", "list_recent"),
        ("⭐ Continue Watching", "list_continue")
    ]
    for title, mode in categories:
        li = xbmcgui.ListItem(label=title)
        url = build_url({"mode": mode})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# ==================== 1. MOVIES & COLLECTIONS V2 ====================

def list_movies():
    movies = fetch_json("data_c01.json")
    movie_dict = {}
    for m in movies:
        t = get_clean_title(m)
        if t not in movie_dict:
            movie_dict[t] = []
        movie_dict[t].append(m)

    for title, items in movie_dict.items():
        m = items[0]
        poster = m.get("poster", "")
        fanart = m.get("fanart", "")
        plot = m.get("plot", "")
        trailer_url = extract_trailer_url(m)
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        
        info_labels = {
            "title": title,
            "plot": plot,
            "mediatype": "movie",
            "rating": float(m.get("rating", 0) or 0),
            "year": int(m.get("year", 2026) or 2026)
        }
        if trailer_url:
            info_labels["trailer"] = trailer_url

        li.setInfo("video", info_labels)
        li.setProperty("IsPlayable", "true")

        url = build_url({"mode": "play_movie_dialog", "title": title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_collections():
    """Auto-groups franchises (Part 1, 2, Sets) via API / Pattern"""
    movies = fetch_json("data_c01.json")
    collections = {}

    for m in movies:
        title = get_clean_title(m)
        col_name = detect_collection_name(title, m)
        if col_name:
            if col_name not in collections:
                collections[col_name] = []
            collections[col_name].append(m)

    for col_name, items in collections.items():
        if len(items) > 1:  # Only show sets with 2 or more titles
            poster = items[0].get("poster", "")
            fanart = items[0].get("fanart", "")
            label = f"📦 {col_name} Collection ({len(items)} Parts)"
            li = xbmcgui.ListItem(label=label)
            li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
            li.setInfo("video", {"title": label, "plot": f"Complete {col_name} Franchise Collection"})
            url = build_url({"mode": "view_collection", "col_name": col_name})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def view_collection(target_col):
    movies = fetch_json("data_c01.json")
    matched = [m for m in movies if detect_collection_name(get_clean_title(m), m) == target_col]
    
    # Auto-sort Part 1, Part 2 sequentially
    matched.sort(key=lambda x: get_clean_title(x))

    # Add Play Entire Collection as Smart Playlist Option
    play_all_li = xbmcgui.ListItem(label=f"▶ Play All {target_col} in Sequence")
    play_all_li.setArt({"thumb": matched[0].get("poster", "")})
    play_all_url = build_url({"mode": "play_smart_playlist", "col_name": target_col})
    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=play_all_url, listitem=play_all_li, isFolder=False)

    for m in matched:
        title = get_clean_title(m)
        poster = m.get("poster", "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": m.get("fanart", "")})
        li.setInfo("video", {"title": title, "plot": m.get("plot", ""), "mediatype": "movie"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_movie_dialog", "title": title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

# ==================== 2. SMART PLAYLISTS V2 ====================

def list_playlists():
    playlists = [
        ("🎵 Play All 5.1 / Atmos Songs (Binge)", "playlist_songs"),
        ("🔥 Play All Recently Added Movies", "playlist_recent")
    ]
    for label, mode in playlists:
        li = xbmcgui.ListItem(label=label)
        url = build_url({"mode": mode})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_smart_playlist(col_name=None, mode_type=None):
    """Queues items sequentially into Kodi native playlist player"""
    playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    playlist.clear()

    if col_name:
        movies = fetch_json("data_c01.json")
        items = [m for m in movies if detect_collection_name(get_clean_title(m), m) == col_name]
        items.sort(key=lambda x: get_clean_title(x))
        for m in items:
            title = get_clean_title(m)
            versions = m.get("versions", [])
            stream = versions[0].get("stream_url", m.get("stream_url", "")) if versions else m.get("stream_url", "")
            if stream:
                li = xbmcgui.ListItem(label=title, path=stream)
                li.setArt({"thumb": m.get("poster", "")})
                li.setInfo("video", {"title": title, "mediatype": "movie"})
                playlist.add(stream, li)

    elif mode_type == "songs":
        songs = fetch_json("data_c03.json")
        playlist = xbmc.PlayList(xbmc.PLAYLIST_MUSIC)
        playlist.clear()
        for s in songs:
            stream = s.get("stream_url", "")
            if stream:
                li = xbmcgui.ListItem(label=s.get("title", "Song"), path=stream)
                li.setArt({"thumb": s.get("poster", "")})
                playlist.add(stream, li)

    xbmc.Player().play(playlist)

# ==================== 3. SEARCH V2 ====================

def search_menu():
    keyboard = xbmc.Keyboard("", "Search Movies, Series, Collections")
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText().strip():
        query = keyboard.getText().strip().lower()
        movies = fetch_json("data_c01.json")
        matched = []
        for m in movies:
            t = get_clean_title(m).lower()
            p = m.get("plot", "").lower()
            if query in t or query in p:
                matched.append(m)

        if not matched:
            dialog = xbmcgui.Dialog()
            dialog.notification("MoinuFlix", f"No results found for '{query}'", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        for m in matched:
            title = get_clean_title(m)
            poster = m.get("poster", "")
            li = xbmcgui.ListItem(label=title)
            li.setArt({"poster": poster, "thumb": poster, "fanart": m.get("fanart", "")})
            li.setInfo("video", {"title": title, "plot": m.get("plot", ""), "mediatype": "movie"})
            li.setProperty("IsPlayable", "true")
            url = build_url({"mode": "play_movie_dialog", "title": title})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

        xbmcplugin.setContent(ADDON_HANDLE, "movies")
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

# ==================== 4. ONLINE CONTINUE WATCHING SYNC V2 ====================

def list_continue():
    """Fetches real-time watch history or falls back to recently watched"""
    try:
        req = urllib.request.Request(f"{WORKER_API_BASE}/api/continue", headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=4) as res:
            history = json.loads(res.read().decode("utf-8"))
            if history:
                for item in history:
                    title = item.get("title", "Movie")
                    poster = item.get("poster", "")
                    resume_time = item.get("resume_time", 0)
                    li = xbmcgui.ListItem(label=f"▶ {title} (Resume at {int(resume_time)//60}m)")
                    li.setArt({"poster": poster, "thumb": poster})
                    li.setProperty("IsPlayable", "true")
                    url = build_url({"mode": "play_direct", "url": item.get("stream_url", ""), "title": title, "poster": poster})
                    xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
                xbmcplugin.setContent(ADDON_HANDLE, "movies")
                xbmcplugin.endOfDirectory(ADDON_HANDLE)
                return
    except Exception:
        pass
    list_recent()

# ==================== STREAM PLAYBACK & DIALOG ====================

def play_movie_dialog(target_title):
    movies = fetch_json("data_c01.json")
    matched_streams = []
    
    for m in movies:
        if get_clean_title(m) == target_title:
            versions = m.get("versions", [])
            if versions:
                for v in versions:
                    q = v.get("quality") or v.get("resolution") or (v.get("specs") or {}).get("resolution", "HD")
                    a = v.get("audio") or (v.get("specs") or {}).get("audio", "")
                    ch = v.get("channels") or (v.get("specs") or {}).get("channels", "")
                    label = f"{q} • {a} {ch}".strip().strip("•")
                    matched_streams.append({
                        "label": label if label else "Default Quality",
                        "url": v.get("stream_url", ""),
                        "poster": m.get("poster", "")
                    })
            else:
                specs = m.get("specs", {})
                q = specs.get("resolution") or m.get("quality", "HD")
                a = specs.get("audio") or m.get("audio", "")
                ch = specs.get("channels") or m.get("channels", "")
                label = f"{q} • {a} {ch}".strip().strip("•")
                matched_streams.append({
                    "label": label if label else "Default Quality",
                    "url": m.get("stream_url", ""),
                    "poster": m.get("poster", "")
                })

    if not matched_streams:
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return

    if len(matched_streams) == 1:
        chosen = matched_streams[0]
        play_stream(chosen["url"], target_title, chosen["poster"])
        return

    dialog_labels = [item["label"] for item in matched_streams]
    dialog = xbmcgui.Dialog()
    selected_index = dialog.select(f"Select Quality - {target_title}", dialog_labels)
    
    if selected_index >= 0:
        chosen = matched_streams[selected_index]
        play_stream(chosen["url"], target_title, chosen["poster"])
    else:
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

def play_stream(stream_url, title, poster=""):
    li = xbmcgui.ListItem(label=title, path=stream_url)
    li.setArt({"poster": poster, "thumb": poster})
    li.setInfo("video", {"title": title, "mediatype": "movie"})
    li.setProperty("IsPlayable", "true")
    # Buffer optimization headers
    li.setProperty("inputstream.adaptive.manifest_type", "mp4")
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

# ==================== REMAINING SECTIONS SAFE ====================

def list_series():
    shows = fetch_json("data_c02.json")
    for s in shows:
        title = s.get("title", "Series")
        poster = s.get("poster", "")
        fanart = s.get("fanart", "")
        trailer_url = extract_trailer_url(s)
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        info_labels = {"title": title, "plot": s.get("plot", ""), "mediatype": "tvshow"}
        if trailer_url:
            info_labels["trailer"] = trailer_url
            
        li.setInfo("video", info_labels)
        url = build_url({"mode": "episodes", "tmdb_id": str(s.get("tmdb_id", ""))})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.setContent(ADDON_HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(tmdb_id):
    shows = fetch_json("data_c02.json")
    show = next((s for s in shows if str(s.get("tmdb_id", "")) == str(tmdb_id)), None)
    if not show:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    episodes = show.get("episodes", [])
    poster = show.get("poster", "")
    fanart = show.get("fanart", "")
    for ep in episodes:
        title = ep.get("title", ep.get("name", "Episode"))
        stream = ep.get("stream_url", "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "plot": ep.get("plot", ""), "mediatype": "episode"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": stream, "title": title, "poster": poster})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "episodes")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_songs():
    songs = fetch_json("data_c03.json")
    for s in songs:
        title = s.get("title", "Song")
        poster = s.get("poster", "")
        stream = s.get("stream_url", "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"thumb": poster, "poster": poster, "fanart": poster})
        li.setInfo("music", {"title": title})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": stream, "title": title, "poster": poster})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vault():
    vault = fetch_json("data_c04.json")
    for v in vault:
        title = v.get("title", "Clip")
        thumb = v.get("thumbnail", "")
        stream = v.get("stream_url", "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"thumb": thumb, "poster": thumb, "fanart": thumb})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": stream, "title": title, "poster": thumb})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_recent():
    movies = fetch_json("data_c01.json")
    for m in movies[:15]:
        title = get_clean_title(m)
        poster = m.get("poster", "")
        versions = m.get("versions", [])
        stream = versions[0].get("stream_url", m.get("stream_url", "")) if versions else m.get("stream_url", "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster})
        li.setInfo("video", {"title": title, "mediatype": "movie"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": stream, "title": title, "poster": poster})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

if __name__ == "__main__":
    qs = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(qs))
    mode = params.get("mode")
    if mode == "list_movies": list_movies()
    elif mode == "play_movie_dialog": play_movie_dialog(params.get("title", ""))
    elif mode == "play_direct": play_stream(params.get("url", ""), params.get("title", ""), params.get("poster", ""))
    elif mode == "list_collections": list_collections()
    elif mode == "view_collection": view_collection(params.get("col_name", ""))
    elif mode == "list_playlists": list_playlists()
    elif mode == "playlist_songs": play_smart_playlist(mode_type="songs")
    elif mode == "play_smart_playlist": play_smart_playlist(col_name=params.get("col_name"))
    elif mode == "search": search_menu()
    elif mode == "list_series": list_series()
    elif mode == "episodes": list_episodes(params.get("tmdb_id", ""))
    elif mode == "list_songs": list_songs()
    elif mode == "list_vault": list_vault()
    elif mode == "list_recent": list_recent()
    elif mode == "list_continue": list_continue()
    else: main_menu()
