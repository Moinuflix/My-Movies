# -*- coding: utf-8 -*-
import sys, os, json, urllib.parse, urllib.request, time
import xbmc, xbmcgui, xbmcplugin, xbmcvfs

BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
RAW_GITHUB = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"
WORKER_BASE = "https://gdrive-stream.moinudeentv.workers.dev"
API_CONTINUE = f"{WORKER_BASE}/api/continue"
API_PROGRESS = f"{WORKER_BASE}/api/progress"
CUSTOM_UA = "Kodi-MoinuTV-PrivatePlayer/1.0"

def get_cache_dir():
    try: return xbmcvfs.translatePath("special://temp/moinuflix_cache")
    except Exception: return os.path.expanduser("~/moinuflix_cache")

CACHE_DIR = get_cache_dir()
LOCAL_RESUME_FILE = os.path.join(CACHE_DIR, "resume_state.json")
LOCAL_HISTORY_FILE = os.path.join(CACHE_DIR, "watch_history.json")
try: os.makedirs(CACHE_DIR, exist_ok=True)
except Exception: pass

def build_url(query): 
    return BASE_URL + "?" + urllib.parse.urlencode(query)

# Instant Cache First Engine (Fix 4: No Network UI Freezing)
def get_json_data(chunk_name):
    if not chunk_name: return []
    cache_file = os.path.join(CACHE_DIR, chunk_name)
    cached_data = None
    
    if os.path.exists(cache_file):
        try:
            with open(cache_file, "r", encoding="utf-8") as f:
                cached_data = json.load(f)
        except Exception:
            cached_data = None

    # Agar cached data maujood hai toh foran return karein
    if cached_data and isinstance(cached_data, list):
        return cached_data

    # Agar cache nahi hai toh quick timeout ke sath fetch karein
    url = f"{RAW_GITHUB}{chunk_name}?t={int(time.time())}"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": CUSTOM_UA})
        with urllib.request.urlopen(req, timeout=4) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            if isinstance(data, list):
                with open(cache_file, "w", encoding="utf-8") as f:
                    json.dump(data, f)
                return data
    except Exception:
        pass

    return cached_data if isinstance(cached_data, list) else []

# Multi-Language Audio Parser
def extract_languages(movie):
    langs = []
    specs = movie.get("specs") or {}
    primary_audio = str(specs.get("audio", "") or movie.get("audio", "")).lower()
    
    mapping = [("tam", "Tamil"), ("hin", "Hindi"), ("tel", "Telugu"), ("eng", "English"), ("mal", "Malayalam"), ("kan", "Kannada")]
    for key, name in mapping:
        if key in primary_audio and name not in langs:
            langs.append(name)
            
    for v in (movie.get("versions") or []):
        v_audio = str(v.get("audio", "")).lower()
        for key, name in mapping:
            if key in v_audio and name not in langs:
                langs.append(name)
                
    if not langs:
        orig = str(movie.get("original_language", "")).lower()
        orig_map = {"ta": "Tamil", "hi": "Hindi", "te": "Telugu", "en": "English", "ml": "Malayalam", "kn": "Kannada"}
        if orig in orig_map:
            langs.append(orig_map[orig])
            
    return langs

def load_local_resume():
    if os.path.exists(LOCAL_RESUME_FILE):
        try:
            with open(LOCAL_RESUME_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception: pass
    return {}

def save_local_resume(stream_url, item_info, current_time, total_time):
    data = load_local_resume()
    if total_time > 0 and (current_time / total_time) >= 0.90:
        if stream_url in data: del data[stream_url]
    elif current_time > 15:
        data[stream_url] = {
            "title": item_info.get("title", "Unknown"),
            "poster": item_info.get("poster", ""),
            "fanart": item_info.get("fanart", ""),
            "plot": item_info.get("plot", ""),
            "studio": item_info.get("studio", "MoinuFlix"),
            "current_time": current_time,
            "total_time": total_time,
            "stream_url": stream_url,
            "updated_at": int(time.time())
        }
    try:
        with open(LOCAL_RESUME_FILE, "w", encoding="utf-8") as f:
            json.dump(data, f)
    except Exception: pass

def push_online_progress(item_data):
    try:
        payload = json.dumps(item_data).encode("utf-8")
        req = urllib.request.Request(API_PROGRESS, data=payload, headers={"User-Agent": CUSTOM_UA, "Content-Type": "application/json"}, method="POST")
        urllib.request.urlopen(req, timeout=2)
    except Exception: pass

class MoinuFlixPlayer(xbmc.Player):
    def __init__(self):
        super(MoinuFlixPlayer, self).__init__()
        self.stream_url = ""
        self.item_info = {}

    def set_tracking(self, stream_url, item_info):
        self.stream_url = stream_url
        self.item_info = item_info

    def onPlayBackStopped(self):
        try:
            curr = self.getTime()
            total = self.getTotalTime()
            if self.stream_url:
                save_local_resume(self.stream_url, self.item_info, curr, total)
                payload = dict(self.item_info)
                payload.update({"stream_url": self.stream_url, "current_time": curr, "total_time": total})
                push_online_progress(payload)
        except Exception: pass

    def onPlayBackEnded(self):
        try:
            total = self.getTotalTime()
            if self.stream_url:
                save_local_resume(self.stream_url, self.item_info, total, total)
                payload = dict(self.item_info)
                payload.update({"stream_url": self.stream_url, "current_time": total, "total_time": total})
                push_online_progress(payload)
        except Exception: pass

GLOBAL_PLAYER = MoinuFlixPlayer()

# Fix 3: Arctic Fuse 2 Safe Auto-Setup (No broken XML build calls)
def safe_auto_configure():
    try:
        skin = xbmc.getSkinDir()
        if "fuse" in skin.lower():
            hub_dir = xbmcvfs.translatePath("special://profile/addon_data/skin.arctic.fuse.2/")
            os.makedirs(hub_dir, exist_ok=True)
    except Exception: pass

def main_menu():
    safe_auto_configure()
    categories = [
        {"title": "[B][COLOR deepskyblue]🔍 Search Master Library[/COLOR][/B]", "action": "search", "chunk": "", "icon": "DefaultAddonsSearch.png"},
        {"title": "[B][COLOR cyan]🕒 Continue Watching (Dual-Sync)[/COLOR][/B]", "action": "continue_watching", "chunk": "", "icon": "DefaultInProgressShows.png"},
        {"title": "[B][COLOR gold]🔥 Trending Top Picks (Main Master)[/COLOR][/B]", "action": "trending_view", "chunk": "", "icon": "DefaultRecentlyAddedMovies.png"},
        {"title": "[B][COLOR magenta]👑 Franchise Collections[/COLOR][/B]", "action": "list_collections", "chunk": "", "icon": "DefaultSets.png"},
        {"title": "[B][COLOR yellow]⚡ IMAX Core Lossless[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_imax.json", "icon": "DefaultVideo.png"},
        {"title": "[B][COLOR cyan]🌴 Kollywood (Tamil Strict)[/COLOR][/B]", "action": "list_tamil_strict", "chunk": "data_c01_tamil.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR lightgreen]🏛️ Tollywood (Telugu)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_telugu.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR yellow]✨ Bollywood (Hindi)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_hindi.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR skyblue]🌐 Hollywood (English)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_english.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR lime]🥥 Mollywood (Malayalam)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_malayalam.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR orange]🏔️ Sandalwood (Kannada)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_kannada.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR springgreen]🧸 Kids[/COLOR][/B]", "action": "list_movies", "chunk": "data_c05_kids.json", "icon": "DefaultMovies.png"},
        {"title": "[B][COLOR red]🎞️ YouTube Action Vault[/COLOR][/B]", "action": "list_vault", "chunk": "vault_action.json", "icon": "DefaultVideo.png"},
        {"title": "[B][COLOR red]💥 YouTube Trailers Vault[/COLOR][/B]", "action": "list_vault", "chunk": "vault_trailers.json", "icon": "DefaultVideo.png"},
        {"title": "[B][COLOR red]😂 YouTube Comedy Vault[/COLOR][/B]", "action": "list_vault", "chunk": "vault_comedy.json", "icon": "DefaultVideo.png"},
        {"title": "[B][COLOR orange]🎵 5.1 Surround Master Video Tracks[/COLOR][/B]", "action": "list_songs", "chunk": "data_c03.json", "icon": "DefaultMusicVideos.png"}
    ]
    for cat in categories:
        li = xbmcgui.ListItem(label=cat["title"])
        li.setArt({"icon": cat["icon"], "thumb": cat["icon"]})
        url = build_url({"action": cat["action"], "chunk": cat["chunk"]})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.setContent(HANDLE, "files")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=True)

# Fix 1 & Fix 2: Clean Metadata + No False IsPlayable Crash
def display_movie_items(movies, chunk_file):
    xbmcplugin.setContent(HANDLE, "movies")
    for m in movies:
        title = m.get("title") or m.get("name") or "Movie"
        year_val = m.get("year", "2024")
        year_str = str(year_val).strip()
        poster = m.get("poster") or ""
        fanart = m.get("fanart") or ""
        plot = m.get("plot") or ""
        rating = float(str(m.get("rating", 7.0)).strip() or 7.0)
        studio = m.get("studio") or (m.get("specs") or {}).get("source") or "Amazon Prime Video"
        trailer = m.get("trailer") or ""
        
        langs = extract_languages(m)
        lang_str = " + ".join(langs) if langs else "Multi"
        badge = f" [COLOR cyan][{lang_str}][/COLOR]"
        
        v_count = len(m.get("versions") or [])
        v_badge = f" [COLOR lime][{v_count} Prints][/COLOR]" if v_count > 1 else ""

        full_label = f"[B]{title}[/B] ({year_str}){badge}{v_badge}"
        li = xbmcgui.ListItem(label=full_label)
        li.setArt({"thumb": poster, "poster": poster, "fanart": fanart, "icon": "DefaultMovies.png"})
        
        try:
            vtag = li.getVideoInfoTag()
            vtag.setTitle(title)
            vtag.setMediaType("movie")
            if year_str.isdigit():
                vtag.setYear(int(year_str))
            vtag.setRating(rating)
            info_plot = f"Available Audio: {lang_str}\n\n{plot}"
            vtag.setPlot(info_plot)
            vtag.setStudios([studio])
        except Exception:
            pass

        if trailer:
            yt_id = ""
            if "v=" in trailer: yt_id = trailer.split("v=")[1].split("&")[0]
            elif "youtu.be/" in trailer: yt_id = trailer.split("youtu.be/")[1].split("?")[0]
            if yt_id:
                yt_url = f"plugin://plugin.video.youtube/play/?video_id={yt_id}"
                li.addContextMenuItems([("🎬 Watch Official Trailer", f"PlayMedia({yt_url})")])

        # Action item folder ki tarah open hoga, isPlayable false taaki dialog safely khul sake
        url = build_url({"action": "prepare_play", "chunk": chunk_file, "tmdb_id": str(m.get("tmdb_id", "")), "raw_id": str(m.get("id", ""))})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=True)

# Strict TMDB Tamil Sorting
def list_tamil_strict(chunk_file):
    movies = get_json_data(chunk_file)
    strict_tamil = []
    other_tamil_dubbed = []
    
    for m in movies:
        orig = str(m.get("original_language", "")).lower()
        if orig == "ta":
            strict_tamil.append(m)
        else:
            other_tamil_dubbed.append(m)
            
    # Pehle pure Tamil movies dikhayenge, phir dubbed
    ordered_list = strict_tamil + other_tamil_dubbed
    display_movie_items(ordered_list, chunk_file)

# Dedicated Kids & Animation Vault
def list_kids_vault(chunk_file):
    all_movies = get_json_data(chunk_file)
    if not all_movies:
        all_movies = get_json_data("data_c01.json")
        
    kids_list = []
    for m in all_movies:
        genres = [str(g).lower() for g in m.get("genres", [])]
        title = (m.get("title") or "").lower()
        plot = (m.get("plot") or "").lower()
        
        if "animation" in genres or "family" in genres or "kids" in genres or "cartoon" in plot or "animation" in plot:
            kids_list.append(m)
            
    if not kids_list:
        kids_list = all_movies[:30] # Fallback
        
    display_movie_items(kids_list, chunk_file)

def list_movies(chunk_file):
    movies = get_json_data(chunk_file)
    if not movies:
        xbmcgui.Dialog().notification("MoinuFlix", "Category Empty", xbmcgui.NOTIFICATION_WARNING, 2000)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    display_movie_items(movies, chunk_file)

# Version & Audio Selection Dialog (Safe Execution)
def prepare_play(chunk_file, tmdb_id, raw_id):
    movies = get_json_data(chunk_file)
    movie = None
    for m in movies:
        if tmdb_id and str(m.get("tmdb_id")) == str(tmdb_id) and tmdb_id != "0":
            movie = m; break
        elif raw_id and str(m.get("id")) == str(raw_id):
            movie = m; break
            
    if not movie:
        xbmcgui.Dialog().notification("MoinuFlix", "Metadata Error!", xbmcgui.NOTIFICATION_ERROR, 2000)
        return

    versions = movie.get("versions") or []
    stream_url = movie.get("stream_url", "")
    
    if len(versions) > 1:
        options = []
        for v in versions:
            q = v.get("quality") or v.get("resolution") or "1080p FHD"
            src = v.get("source") or v.get("studio") or "WEB-DL"
            aud = v.get("audio") or "5.1 Surround"
            sz = (v.get("specs") or {}).get("size") or v.get("size") or ""
            options.append(f"{q} • {src} • {aud}" + (f" [{sz}]" if sz else ""))
        sel = xbmcgui.Dialog().select("Select Audio / Quality Print", options)
        if sel < 0: return
        stream_url = versions[sel].get("stream_url") or stream_url
    elif len(versions) == 1:
        stream_url = versions[0].get("stream_url") or stream_url

    local_data = load_local_resume()
    resume_time = 0
    if stream_url in local_data:
        saved_curr = int(local_data[stream_url].get("current_time", 0))
        if saved_curr > 20:
            mins, secs = divmod(saved_curr, 60)
            hrs, mins = divmod(mins, 60)
            t_str = f"{hrs:02d}:{mins:02d}:{secs:02d}" if hrs else f"{mins:02d}:{secs:02d}"
            ch = xbmcgui.Dialog().yesno("Dual-Sync Resume", f"Resume playback from {t_str}?", yeslabel="Resume", nolabel="Restart")
            if ch: resume_time = saved_curr

    play_direct(
        stream_url=stream_url, 
        title=movie.get("title", "Movie"), 
        poster=movie.get("poster", ""), 
        fanart=movie.get("fanart", ""), 
        plot=movie.get("plot", ""), 
        studio=movie.get("studio", "Amazon Prime Video"), 
        resume_time=str(resume_time)
    )

def play_direct(stream_url, title="", poster="", fanart="", plot="", studio="Amazon Prime Video", resume_time="0"):
    if not stream_url:
        xbmcgui.Dialog().notification("MoinuFlix", "No Stream URL Found", xbmcgui.NOTIFICATION_ERROR, 2000)
        return
    item_info = {"title": title, "poster": poster, "fanart": fanart, "plot": plot, "studio": studio, "mediatype": "movie"}
    GLOBAL_PLAYER.set_tracking(stream_url, item_info)
    
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    try:
        vtag = play_item.getVideoInfoTag()
        vtag.setTitle(title)
        vtag.setMediaType("movie")
        vtag.setPlot(plot)
        vtag.setStudios([studio])
    except Exception: pass

    r_time = float(resume_time) if resume_time.replace(".", "", 1).isdigit() else 0.0
    if r_time > 0:
        play_item.setProperty("StartOffset", str(r_time))
    
    GLOBAL_PLAYER.play(stream_url, play_item)
    monitor = xbmc.Monitor()
    # Script ko active rakhein taaki Stop event pakad sake
    xbmc.sleep(2000)
    while not monitor.abortRequested() and GLOBAL_PLAYER.isPlaying():
        xbmc.sleep(1000)

def search_system():
    kb = xbmc.Keyboard("", "Search MoinuFlix Library")
    kb.doModal()
    if not kb.isConfirmed(): return
    query = kb.getText().strip().lower()
    if not query: return
    movies = get_json_data("data_c01.json")
    results = [m for m in movies if query in (m.get("title") or "").lower() or query in (m.get("original_title") or "").lower()]
    if not results:
        xbmcgui.Dialog().notification("MoinuFlix", f"No items found for: {query}", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    display_movie_items(results, "data_c01.json")

def show_trending():
    movies = get_json_data("data_c01.json")
    trending = sorted(movies, key=lambda x: float(str(x.get("rating", 0)).strip() or 0), reverse=True)[:25]
    display_movie_items(trending, "data_c01.json")

def list_collections():
    movies = get_json_data("data_c01.json")
    sets = {}
    for m in movies:
        col = (m.get("collection") or "").strip()
        if col: sets.setdefault(col, []).append(m)
    if not sets:
        xbmcgui.Dialog().notification("MoinuFlix", "No Collections Found", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    for c_name, m_list in sets.items():
        sample = m_list[0]
        li = xbmcgui.ListItem(label=f"[B][COLOR magenta]👑 {c_name}[/COLOR][/B] [COLOR cyan]({len(m_list)} Parts)[/COLOR]")
        li.setArt({"poster": sample.get("poster", ""), "thumb": sample.get("poster", ""), "fanart": sample.get("fanart", ""), "icon": "DefaultSets.png"})
        url = build_url({"action": "view_collection_parts", "collection_name": c_name})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.setContent(HANDLE, "sets")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=True)

def view_collection_parts(c_name):
    movies = get_json_data("data_c01.json")
    parts = sorted([m for m in movies if (m.get("collection") or "").strip() == c_name], key=lambda x: int(x.get("year", 2024)))
    display_movie_items(parts, "data_c01.json")

def show_continue_watching():
    local_data = load_local_resume()
    if not local_data:
        xbmcgui.Dialog().notification("MoinuFlix", "No Watch History Found", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(HANDLE)
        return
    sorted_history = sorted(local_data.values(), key=lambda x: x.get("updated_at", 0), reverse=True)
    for h in sorted_history:
        title = h.get("title", "Continue Video")
        stream_url = h.get("stream_url", "")
        curr = int(h.get("current_time", 0))
        mins, secs = divmod(curr, 60)
        hrs, mins = divmod(mins, 60)
        time_str = f"{hrs:02d}:{mins:02d}:{secs:02d}" if hrs else f"{mins:02d}:{secs:02d}"
        li = xbmcgui.ListItem(label=f"[COLOR cyan]▶[/COLOR] [B]{title}[/B] [COLOR gold]({time_str})[/COLOR]")
        li.setArt({"thumb": h.get("poster", ""), "poster": h.get("poster", ""), "fanart": h.get("fanart", "")})
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title, "poster": h.get("poster", ""), "resume_time": str(curr)})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=True)

def list_songs(chunk_file):
    songs_data = get_json_data(chunk_file)
    xbmcplugin.setContent(HANDLE, "musicvideos")
    for s in songs_data:
        title = s.get("title") or s.get("name") or "5.1 Track"
        poster = s.get("poster") or ""
        stream_url = s.get("stream_url") or ""
        li = xbmcgui.ListItem(label=f"[COLOR orange]🎵 {title}[/COLOR]")
        li.setArt({"thumb": poster, "poster": poster, "fanart": s.get("fanart", "")})
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title, "poster": poster})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=True)

def list_vault(chunk_file):
    vault = get_json_data(chunk_file)
    xbmcplugin.setContent(HANDLE, "videos")
    for v in vault:
        title = v.get("title") or "Vault Video"
        li = xbmcgui.ListItem(label=f"[COLOR red]{title}[/COLOR]")
        li.setArt({"thumb": v.get("thumbnail") or ""})
        url = build_url({"action": "play_direct", "stream_url": v.get("stream_url") or "", "title": title})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=True)

def router():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and len(sys.argv[2]) > 1 else ""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    chunk = params.get("chunk", "")
    if not action: main_menu()
    elif action == "search": search_system()
    elif action == "continue_watching": show_continue_watching()
    elif action == "trending_view": show_trending()
    elif action == "list_collections": list_collections()
    elif action == "view_collection_parts": view_collection_parts(params.get("collection_name", ""))
    elif action == "list_movies": list_movies(chunk)
    elif action == "list_tamil_strict": list_tamil_strict(chunk)
    elif action == "list_kids_vault": list_kids_vault(chunk)
    elif action == "prepare_play": prepare_play(chunk, params.get("tmdb_id", ""), params.get("raw_id", ""))
    elif action == "play_direct": play_direct(stream_url=params.get("stream_url", ""), title=params.get("title", ""), poster=params.get("poster", ""), fanart=params.get("fanart", ""), plot=params.get("plot", ""), studio=params.get("studio", "Amazon Prime Video"), resume_time=params.get("resume_time", "0"))
    elif action == "list_songs": list_songs(chunk)
    elif action == "list_vault": list_vault(chunk)

if __name__ == "__main__":
    router()
