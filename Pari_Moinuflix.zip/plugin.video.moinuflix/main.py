# -*- coding: utf-8 -*-
import sys
import os
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
RAW_GITHUB = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"

def get_cache_dir():
    try:
        return xbmcvfs.translatePath("special://temp/moinuflix_cache")
    except:
        return os.path.expanduser("~/moinuflix_cache")

CACHE_DIR = get_cache_dir()
try:
    os.makedirs(CACHE_DIR, exist_ok=True)
except:
    pass

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def get_json_data(chunk_name):
    url = RAW_GITHUB + chunk_name
    cache_file = os.path.join(CACHE_DIR, chunk_name)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            try:
                with open(cache_file, "w", encoding="utf-8") as f:
                    json.dump(data, f)
            except:
                pass
            return data
    except Exception as e:
        if os.path.exists(cache_file):
            try:
                with open(cache_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except:
                pass
    return []

def main_menu():
    categories = [
        {"title": "[B][COLOR cyan]🌴 Kollywood (Tamil)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_tamil.json"},
        {"title": "[B][COLOR lightgreen]🏛️ Tollywood (Telugu)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_telugu.json"},
        {"title": "[B][COLOR yellow]✨ Bollywood (Hindi)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_hindi.json"},
        {"title": "[B][COLOR skyblue]🌐 Hollywood (English / Multi)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_english.json"},
        {"title": "[B][COLOR gold]👑 All Movies Master[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01.json"},
        {"title": "[B][COLOR magenta]📺 Web Series (c02)[/COLOR][/B]", "action": "list_series", "chunk": "data_c02.json"},
        {"title": "[B][COLOR orange]🎵 5.1 Surround Songs (c03)[/COLOR][/B]", "action": "list_songs", "chunk": "data_c03.json"},
        {"title": "[B][COLOR red]🍿 YouTube Vault (c04)[/COLOR][/B]", "action": "list_vault", "chunk": "data_c04.json"}
    ]

    for cat in categories:
        li = xbmcgui.ListItem(label=cat["title"])
        li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
        url = build_url({"action": cat["action"], "chunk": cat["chunk"]})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)

def list_movies(chunk_file):
    movies = get_json_data(chunk_file)
    if not movies:
        xbmcgui.Dialog().notification("MoinuFlix", "Loading failed or empty chunk!", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for idx, m in enumerate(movies):
        title = m.get("title") or m.get("name") or "Unknown"
        year = str(m.get("year", ""))
        rating = str(m.get("rating", "7.5"))
        poster = m.get("poster") or ""
        fanart = m.get("fanart") or ""
        plot = m.get("plot") or ""
        
        specs = m.get("specs") or {}
        source = specs.get("source", "WEB-DL")
        langs = specs.get("languages", "")

        is_multi = ("," in langs) or ("multi" in (m.get("name", "").lower()))
        multi_tag = " [COLOR gold][MULTI][/COLOR]" if is_multi else ""
        ott_tag = f" [COLOR red][{source}][/COLOR]" if source in ["Netflix", "Disney+ Hotstar", "SonyLIV", "Prime Video"] else ""

        display_label = f"{title} ({year}){ott_tag}{multi_tag}"

        li = xbmcgui.ListItem(label=display_label)
        li.setArt({"thumb": poster, "poster": poster, "fanart": fanart, "icon": "DefaultMovies.png"})
        
        try:
            info = {
                "title": title,
                "year": int(year) if year.isdigit() else 0,
                "rating": float(rating) if rating.replace('.', '', 1).isdigit() else 7.0,
                "plot": plot,
                "mediatype": "movie"
            }
            li.setInfo("video", info)
        except:
            pass

        url = build_url({
            "action": "play_movie",
            "chunk": chunk_file,
            "movie_index": idx
        })

        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)

def play_movie(chunk_file, movie_index):
    movies = get_json_data(chunk_file)
    if movie_index >= len(movies):
        return
    movie = movies[movie_index]
    versions = movie.get("versions") or []
    stream_url = movie.get("stream_url", "")

    if len(versions) > 1:
        labels = []
        for v in versions:
            q = v.get("quality") or v.get("resolution") or "Standard"
            src = v.get("source") or "WEB-DL"
            aud = v.get("audio") or ""
            sz = (v.get("specs") or {}).get("size")
            size_txt = f" [{sz}]" if sz else ""
            labels.append(f"{q} • {src} • {aud}{size_txt}")

        dialog = xbmcgui.Dialog()
        sel = dialog.select("Select Quality Version", labels)
        if sel < 0:
            return
        stream_url = versions[sel].get("stream_url") or stream_url
    elif len(versions) == 1:
        stream_url = versions[0].get("stream_url") or stream_url

    if not stream_url:
        xbmcgui.Dialog().notification("MoinuFlix", "No Stream URL found", xbmcgui.NOTIFICATION_ERROR)
        return

    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setInfo("video", {"title": movie.get("title", "")})
    xbmcplugin.setResolvedUrl(HANDLE, True, play_item)

def list_series(chunk_file):
    series = get_json_data(chunk_file)
    for s in series:
        title = s.get("name") or s.get("title") or "Series"
        poster = s.get("poster") or ""
        stream_url = s.get("stream_url") or ""
        li = xbmcgui.ListItem(label=f"[COLOR magenta]{title}[/COLOR]")
        li.setArt({"thumb": poster, "poster": poster, "icon": "DefaultTVShows.png"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)

def list_songs(chunk_file):
    songs = get_json_data(chunk_file)
    for s in songs:
        title = s.get("title") or "5.1 Master Song"
        movie = s.get("movie") or ""
        poster = s.get("poster") or ""
        stream_url = s.get("stream_url") or ""
        li = xbmcgui.ListItem(label=f"[B]{title}[/B] [COLOR orange]({movie})[/COLOR]")
        li.setArt({"thumb": poster, "icon": "DefaultAudio.png"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.endOfDirectory(HANDLE)

def list_vault(chunk_file):
    vault = get_json_data(chunk_file)
    for v in vault:
        title = v.get("title") or "Vault Video"
        thumb = v.get("thumbnail") or ""
        stream_url = v.get("stream_url") or ""
        li = xbmcgui.ListItem(label=f"[COLOR red]{title}[/COLOR]")
        li.setArt({"thumb": thumb, "icon": "DefaultVideo.png"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)

def router():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and len(sys.argv[2]) > 1 else ""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    chunk = params.get("chunk", "")

    if not action:
        main_menu()
    elif action == "list_movies":
        list_movies(chunk)
    elif action == "play_movie":
        play_movie(chunk, int(params.get("movie_index", 0)))
    elif action == "list_series":
        list_series(chunk)
    elif action == "list_songs":
        list_songs(chunk)
    elif action == "list_vault":
        list_vault(chunk)
    elif action == "play_direct":
        stream_url = params.get("stream_url", "")
        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setInfo("video", {"title": params.get("title", "")})
        xbmcplugin.setResolvedUrl(HANDLE, True, play_item)

if __name__ == "__main__":
    router()
