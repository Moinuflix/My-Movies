import sys
import json
import ssl
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
GITHUB_CHUNKS = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"

ctx = ssl.create_default_context()
ctx.check_hostname = False
ctx.verify_mode = ssl.CERT_NONE

def fetch_data(filename):
    url = GITHUB_CHUNKS + filename
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, context=ctx, timeout=15) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception as e:
        xbmc.log(f"[Moinuflix Error] {e}", xbmc.LOGERROR)
        return []

def show_categories():
    categories = [
        ("🎬 Movies", "data_c01.json"),
        ("📺 Series / TV Shows", "data_c02.json"),
        ("🎵 Music", "data_c03.json")
    ]
    for name, filename in categories:
        link = f"{BASE_URL}?file={filename}"
        li = xbmcgui.ListItem(label=name)
        li.setInfo("video", {"title": name})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=link, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_movies(filename):
    movies = fetch_data(filename)
    if not movies:
        li = xbmcgui.ListItem(label="No items found in this category")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for m in movies:
        title = m.get("title") or m.get("name") or "Untitled"
        year = m.get("year")
        label = f"{title} ({year})" if year else title
        
        stream = m.get("stream_url") or m.get("url") or ""
        poster = m.get("poster") or ""
        fanart = m.get("fanart") or ""
        plot = m.get("plot") or ""

        li = xbmcgui.ListItem(label=label)
        info_dict = {"title": label, "plot": plot}
        if year:
            try:
                info_dict["year"] = int(year)
            except:
                pass
        li.setInfo("video", info_dict)
        
        art = {}
        if poster:
            art["thumb"] = poster
            art["poster"] = poster
            art["icon"] = poster
        if fanart:
            art["fanart"] = fanart
        if art:
            li.setArt(art)
        
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=stream, listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    if "file" in params:
        show_movies(params["file"])
    else:
        show_categories()
