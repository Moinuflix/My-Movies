# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import re
import xbmc
import xbmcgui
import xbmcplugin

ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 else 0
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
REPO_RAW_BASE = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"
USER_AGENT = "Kodi-MoinuTV-PrivatePlayer/2.0"
ICON_URL = "https://res.cloudinary.com/dwigabwtq/image/upload/v1788716131/pari_queen_n1f5zl.png"
TMDB_KEY = "3c3e800c7f7e91d57579709230554c5a"

LANG_MAP = {
    "tamil": ["ta"],
    "telugu": ["te"],
    "hindi": ["hi"],
    "english": ["en"]
}

MEM_CACHE = {}

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def fetch_json(filename):
    url = REPO_RAW_BASE + filename
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception as e:
        xbmc.log("[MoinuFlix] Error loading " + filename + ": " + str(e), xbmc.LOGERROR)
        return []

def get_clean_title(item):
    return item.get("title") or item.get("name") or "Unknown"

def get_tmdb_orig_lang(title, year=None):
    clean_title = re.sub(r"(:?\s*(Part|Chapter|Episode|Vol|Volume)\s*\d+.*|\s+\d+$)", "", title, flags=re.I).strip()
    if clean_title in MEM_CACHE:
        return MEM_CACHE[clean_title]

    try:
        q = urllib.parse.quote(clean_title)
        url = f"https://api.themoviedb.org/3/search/movie?api_key={TMDB_KEY}&query={q}"
        if year:
            url += f"&year={year}"
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=5) as res:
            data = json.loads(res.read().decode("utf-8"))
            results = data.get("results", [])
            if results:
                orig_lang = results[0].get("original_language", "").lower()
                MEM_CACHE[clean_title] = orig_lang
                return orig_lang
    except Exception as e:
        xbmc.log(f"[MoinuFlix] TMDB API Error for {clean_title}: {str(e)}", xbmc.LOGERROR)
    
    MEM_CACHE[clean_title] = ""
    return ""

def extract_trailer_url(item):
    t = item.get("trailer")
    raw = ""
    if isinstance(t, dict):
        raw = t.get("youtube_url") or t.get("url") or ""
    elif isinstance(t, str):
        raw = t
    if not raw:
        return ""
    if "plugin://plugin.video.youtube" in raw:
        return raw
    match = re.search(r"(?:v=|\/|youtu\.be\/)([a-zA-Z0-9_-]{11})", raw)
    if match:
        return f"plugin://plugin.video.youtube/play/?video_id={match.group(1)}"
    elif len(raw.strip()) == 11:
        return f"plugin://plugin.video.youtube/play/?video_id={raw.strip()}"
    return raw

def detect_collection_name(title, item):
    if item.get("collection"):
        return item.get("collection")
    clean = re.sub(r"(:?\s*(Part|Chapter|Episode|Vol|Volume)\s*\d+.*|\s+\d+$)", "", title, flags=re.I).strip()
    return clean if clean != title else None

def main_menu():
    categories = [
        ("Search", "search"),
        ("Recently Added", "list_recent"),
        ("Kollywood (Tamil Movies)", "cat_tamil"),
        ("Tollywood (Telugu Movies)", "cat_telugu"),
        ("Bollywood (Hindi Movies)", "cat_hindi"),
        ("Hollywood (English Movies)", "cat_english"),
        ("Movie Collections / Sets", "list_collections"),
        ("Web Series", "list_series"),
        ("5.1 / Atmos Songs", "list_songs"),
        ("YouTube Vault", "list_vault")
    ]
    for title, mode in categories:
        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": ICON_URL, "thumb": ICON_URL})
        url = build_url({"mode": mode})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def filter_and_show_movies(target_lang):
    movies = fetch_json("data_c01.json")
    movie_dict = {}
    valid_codes = LANG_MAP.get(target_lang.lower(), [])

    dialog = xbmcgui.DialogProgress()
    dialog.create("MoinuFlix", f"Syncing {target_lang.capitalize()} catalog via TMDB...")
    total = len(movies)

    for idx, m in enumerate(movies):
        if dialog.iscanceled():
            break
        t = get_clean_title(m)
        y = m.get("year")
        percent = int(((idx + 1) / float(total)) * 100)
        dialog.update(percent, f"Checking: {t}")

        # Pehle local JSON field check karega, agar nahi hai toh TMDB API call
        orig_lang = str(m.get("original_language") or "").lower().strip()
        if not orig_lang:
            orig_lang = get_tmdb_orig_lang(t, y)

        if orig_lang in valid_codes:
            if t not in movie_dict:
                movie_dict[t] = []
            movie_dict[t].append(m)

    dialog.close()

    if not movie_dict:
        xbmcgui.Dialog().notification("MoinuFlix", f"No {target_lang.capitalize()} titles found", xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    for title, items in movie_dict.items():
        m = items[0]
        poster = m.get("poster") or ICON_URL
        fanart = m.get("fanart", "")
        plot = m.get("plot", "")
        trailer_url = extract_trailer_url(m)
        
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "icon": ICON_URL, "fanart": fanart})
        
        info_labels = {
            "title": title,
            "plot": plot,
            "mediatype": "movie",
            "rating": float(m.get("rating", 0) or 0),
            "year": int(m.get("year", 2026) or 2026)
        }
        if trailer_url:
            info_labels["trailer"] = trailer_url

        li.setInfo("video", info_labels)
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_movie_dialog", "title": title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_collections():
    movies = fetch_json("data_c01.json")
    collections = {}
    for m in movies:
        title = get_clean_title(m)
        col_name = detect_collection_name(title, m)
        if col_name:
            if col_name not in collections:
                collections[col_name] = []
            collections[col_name].append(m)

    for col_name, items in collections.items():
        if len(items) > 1:
            poster = items[0].get("poster") or ICON_URL
            label = f"{col_name} Collection ({len(items)} Parts)"
            li = xbmcgui.ListItem(label=label)
            li.setArt({"poster": poster, "thumb": poster, "icon": ICON_URL, "fanart": items[0].get("fanart", "")})
            li.setInfo("video", {"title": label, "plot": f"Complete {col_name} Franchise Collection"})
            url = build_url({"mode": "view_collection", "col_name": col_name})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def view_collection(target_col):
    movies = fetch_json("data_c01.json")
    matched = [m for m in movies if detect_collection_name(get_clean_title(m), m) == target_col]
    matched.sort(key=lambda x: get_clean_title(x))

    for m in matched:
        title = get_clean_title(m)
        poster = m.get("poster") or ICON_URL
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "icon": ICON_URL, "fanart": m.get("fanart", "")})
        li.setInfo("video", {"title": title, "plot": m.get("plot", ""), "mediatype": "movie"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_movie_dialog", "title": title})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def search_menu():
    keyboard = xbmc.Keyboard("", "Search Movies & Series")
    keyboard.doModal()
    if keyboard.isConfirmed() and keyboard.getText().strip():
        query = keyboard.getText().strip().lower()
        movies = fetch_json("data_c01.json")
        matched = [m for m in movies if query in get_clean_title(m).lower() or query in m.get("plot", "").lower()]

        if not matched:
            xbmcgui.Dialog().notification("MoinuFlix", f"No results for '{query}'", xbmcgui.NOTIFICATION_INFO, 3000)
            return

        for m in matched:
            title = get_clean_title(m)
            poster = m.get("poster") or ICON_URL
            li = xbmcgui.ListItem(label=title)
            li.setArt({"poster": poster, "thumb": poster, "icon": ICON_URL, "fanart": m.get("fanart", "")})
            li.setInfo("video", {"title": title, "plot": m.get("plot", ""), "mediatype": "movie"})
            li.setProperty("IsPlayable", "true")
            url = build_url({"mode": "play_movie_dialog", "title": title})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

        xbmcplugin.setContent(ADDON_HANDLE, "movies")
        xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_movie_dialog(target_title):
    movies = fetch_json("data_c01.json")
    matched_streams = []
    
    for m in movies:
        if get_clean_title(m) == target_title:
            versions = m.get("versions", [])
            if versions:
                for v in versions:
                    q = v.get("quality") or v.get("resolution") or (v.get("specs") or {}).get("resolution", "HD")
                    a = v.get("audio") or (v.get("specs") or {}).get("audio", "")
                    ch = v.get("channels") or (v.get("specs") or {}).get("channels", "")
                    label = f"{q} • {a} {ch}".strip().strip("•")
                    matched_streams.append({
                        "label": label if label else "Default Quality",
                        "url": v.get("stream_url", ""),
                        "poster": m.get("poster") or ICON_URL
                    })
            else:
                specs = m.get("specs", {})
                q = specs.get("resolution") or m.get("quality", "HD")
                a = specs.get("audio") or m.get("audio", "")
                ch = specs.get("channels") or m.get("channels", "")
                label = f"{q} • {a} {ch}".strip().strip("•")
                matched_streams.append({
                    "label": label if label else "Default Quality",
                    "url": m.get("stream_url", ""),
                    "poster": m.get("poster") or ICON_URL
                })

    if not matched_streams:
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return

    if len(matched_streams) == 1:
        chosen = matched_streams[0]
        play_stream(chosen["url"], target_title, chosen["poster"])
        return

    dialog_labels = [item["label"] for item in matched_streams]
    selected_index = xbmcgui.Dialog().select(f"Select Quality - {target_title}", dialog_labels)
    
    if selected_index >= 0:
        chosen = matched_streams[selected_index]
        play_stream(chosen["url"], target_title, chosen["poster"])
    else:
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

def play_stream(stream_url, title, poster=""):
    li = xbmcgui.ListItem(label=title, path=stream_url)
    art_poster = poster or ICON_URL
    li.setArt({"poster": art_poster, "thumb": art_poster, "icon": ICON_URL})
    li.setInfo("video", {"title": title, "mediatype": "movie"})
    li.setProperty("IsPlayable", "true")
    li.setProperty("inputstream.adaptive.manifest_type", "mp4")
    xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, li)

def list_series():
    shows = fetch_json("data_c02.json")
    for s in shows:
        title = s.get("title", "Series")
        poster = s.get("poster") or ICON_URL
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "icon": ICON_URL, "fanart": s.get("fanart", "")})
        li.setInfo("video", {"title": title, "plot": s.get("plot", ""), "mediatype": "tvshow"})
        url = build_url({"mode": "episodes", "tmdb_id": str(s.get("tmdb_id", ""))})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.setContent(ADDON_HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(tmdb_id):
    shows = fetch_json("data_c02.json")
    show = next((s for s in shows if str(s.get("tmdb_id", "")) == str(tmdb_id)), None)
    if not show:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return
    for ep in show.get("episodes", []):
        title = ep.get("title", ep.get("name", "Episode"))
        stream = ep.get("stream_url", "")
        poster = show.get("poster") or ICON_URL
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "icon": ICON_URL})
        li.setInfo("video", {"title": title, "plot": ep.get("plot", ""), "mediatype": "episode"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": stream, "title": title, "poster": poster})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "episodes")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_songs():
    songs = fetch_json("data_c03.json")
    for s in songs:
        title = s.get("title", "Song")
        poster = s.get("poster") or ICON_URL
        li = xbmcgui.ListItem(label=title)
        li.setArt({"thumb": poster, "poster": poster, "icon": ICON_URL})
        li.setInfo("music", {"title": title})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": s.get("stream_url", ""), "title": title, "poster": poster})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "songs")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vault():
    vault = fetch_json("data_c04.json")
    for v in vault:
        title = v.get("title", "Clip")
        thumb = v.get("thumbnail") or ICON_URL
        li = xbmcgui.ListItem(label=title)
        li.setArt({"thumb": thumb, "poster": thumb, "icon": ICON_URL})
        li.setInfo("video", {"title": title})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": v.get("stream_url", ""), "title": title, "poster": thumb})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_recent():
    movies = fetch_json("data_c01.json")
    for m in movies[:15]:
        title = get_clean_title(m)
        poster = m.get("poster") or ICON_URL
        versions = m.get("versions", [])
        stream = versions[0].get("stream_url", m.get("stream_url", "")) if versions else m.get("stream_url", "")
        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "icon": ICON_URL})
        li.setInfo("video", {"title": title, "mediatype": "movie"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"mode": "play_direct", "url": stream, "title": title, "poster": poster})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

if __name__ == "__main__":
    qs = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(qs))
    mode = params.get("mode")
    
    if mode == "cat_tamil": filter_and_show_movies("tamil")
    elif mode == "cat_telugu": filter_and_show_movies("telugu")
    elif mode == "cat_hindi": filter_and_show_movies("hindi")
    elif mode == "cat_english": filter_and_show_movies("english")
    elif mode == "play_movie_dialog": play_movie_dialog(params.get("title", ""))
    elif mode == "play_direct": play_stream(params.get("url", ""), params.get("title", ""), params.get("poster", ""))
    elif mode == "list_collections": list_collections()
    elif mode == "view_collection": view_collection(params.get("col_name", ""))
    elif mode == "search": search_menu()
    elif mode == "list_series": list_series()
    elif mode == "episodes": list_episodes(params.get("tmdb_id", ""))
    elif mode == "list_songs": list_songs()
    elif mode == "list_vault": list_vault()
    elif mode == "list_recent": list_recent()
    else: main_menu()
