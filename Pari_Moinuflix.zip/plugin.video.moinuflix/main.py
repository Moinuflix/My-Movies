# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 0
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else "plugin://plugin.video.moinuflix/"
REPO_RAW_BASE = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def get_json(filename):
    url = REPO_RAW_BASE + filename
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=10) as r:
            return json.loads(r.read().decode("utf-8"))
    except Exception as e:
        xbmc.log("[MoinuFlix Load Error] " + filename + ": " + str(e), xbmc.LOGERROR)
        return []

def main_menu():
    items = [
        ("🎬 Movies", "movies"),
        ("📺 Web Series", "series"),
        ("🎵 5.1 / Atmos Songs", "songs"),
        ("🍿 YouTube Vault", "vault")
    ]
    for label, mode in items:
        li = xbmcgui.ListItem(label=label, offscreen=True)
        li.setInfo("video", {"title": label, "mediatype": "video"})
        url = build_url({"mode": mode})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE)

def show_movies():
    movies = get_json("data_c01.json")
    for m in movies:
        title = m.get("title", m.get("name", "Movie"))
        year = int(m.get("year", 0)) if str(m.get("year", 0)).isdigit() else 0
        poster = m.get("poster", "")
        fanart = m.get("fanart", "")
        versions = m.get("versions", [])
        v_count = len(versions) if isinstance(versions, list) and versions else 1

        label = f"{title} ({year})" if v_count <= 1 else f"{title} ({year}) [{v_count} Qualities]"
        li = xbmcgui.ListItem(label=label, offscreen=True)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "year": year, "plot": m.get("plot", ""), "mediatype": "movie"})
        li.setProperty("IsPlayable", "true")

        url = build_url({"mode": "play_movie", "tmdb_id": str(m.get("tmdb_id", ""))})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)

def play_movie(tmdb_id):
    movies = get_json("data_c01.json")
    movie = next((m for m in movies if str(m.get("tmdb_id", "")) == str(tmdb_id)), None)
    if not movie:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
        return

    versions = movie.get("versions", [])
    stream = ""

    if not versions or len(versions) <= 1:
        stream = movie.get("stream_url", "")
        if versions and "stream_url" in versions[0]:
            stream = versions[0]["stream_url"]
    else:
        options = []
        for v in versions:
            q = v.get("quality", "1080p")
            res = v.get("resolution", "")
            audio = v.get("audio", "")
            options.append(f"▶ [{q}] {res} • {audio}")

        d = xbmcgui.Dialog()
        choice = d.select(f"Select Quality — {movie.get(title)}", options)
        if choice != -1:
            stream = versions[choice].get("stream_url", "")
        else:
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))
            return

    if stream:
        li = xbmcgui.ListItem(path=stream, offscreen=True)
        xbmcplugin.setResolvedUrl(HANDLE, True, li)
    else:
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem(offscreen=True))

def show_series():
    shows = get_json("data_c02.json")
    for s in shows:
        title = s.get("title", "Series")
        year = int(s.get("year", 0)) if str(s.get("year", 0)).isdigit() else 0
        poster = s.get("poster", "")
        fanart = s.get("fanart", "")
        episodes = s.get("episodes", [])
        ep_count = len(episodes) if isinstance(episodes, list) and episodes else 1

        li = xbmcgui.ListItem(label=f"{title} ({year})", offscreen=True)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "year": year, "plot": f"Total Episodes: {ep_count}\n\n" + s.get("plot", ""), "mediatype": "tvshow"})

        url = build_url({"mode": "episodes", "tmdb_id": str(s.get("tmdb_id", ""))})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)

def show_episodes(tmdb_id):
    shows = get_json("data_c02.json")
    show = next((s for s in shows if str(s.get("tmdb_id", "")) == str(tmdb_id)), None)
    if not show:
        xbmcplugin.endOfDirectory(HANDLE)
        return

    episodes = show.get("episodes", [])
    poster = show.get("poster", "")
    fanart = show.get("fanart", "")

    for ep in episodes:
        title = ep.get("title", ep.get("name", "Episode"))
        stream = ep.get("stream_url", "")
        li = xbmcgui.ListItem(label=title, offscreen=True)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "season": int(ep.get("season", 1)), "episode": int(ep.get("episode", 1)), "plot": ep.get("plot", ""), "mediatype": "episode"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=stream, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)

def show_songs():
    songs = get_json("data_c03.json")
    for s in songs:
        title = s.get("title", "Song")
        poster = s.get("poster", "")
        stream = s.get("stream_url", "")
        specs = s.get("specs", {})
        audio_name = specs.get("audio", "5.1 Surround") if isinstance(specs, dict) else "5.1 Surround"

        li = xbmcgui.ListItem(label=f"🎵 {title} [{audio_name}]", offscreen=True)
        li.setArt({"thumb": poster, "poster": poster, "fanart": poster})
        li.setInfo("video", {"title": title, "plot": s.get("plot", ""), "mediatype": "musicvideo"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=stream, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "musicvideos")
    xbmcplugin.endOfDirectory(HANDLE)

def show_vault():
    vault = get_json("data_c04.json")
    for v in vault:
        title = v.get("title", "Clip")
        cat = v.get("category", "Clip")
        thumb = v.get("thumbnail", "")
        stream = v.get("stream_url", "")

        li = xbmcgui.ListItem(label=f"[{cat}] {title}", offscreen=True)
        li.setArt({"thumb": thumb, "poster": thumb, "fanart": thumb})
        li.setInfo("video", {"title": title, "genre": cat, "mediatype": "video"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=stream, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)

if __name__ == "__main__":
    qs = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
    params = dict(urllib.parse.parse_qsl(qs))
    mode = params.get("mode")

    if mode == "movies": show_movies()
    elif mode == "play_movie": play_movie(params.get("tmdb_id", ""))
    elif mode == "series": show_series()
    elif mode == "episodes": show_episodes(params.get("tmdb_id", ""))
    elif mode == "songs": show_songs()
    elif mode == "vault": show_vault()
    else: main_menu()
