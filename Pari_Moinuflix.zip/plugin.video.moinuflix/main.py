# -*- coding: utf-8 -*-
import sys
import os
import json
import urllib.parse
import urllib.request
import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
RAW_GITHUB = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"

def get_cache_dir():
    try:
        return xbmcvfs.translatePath("special://temp/moinuflix_cache")
    except:
        return os.path.expanduser("~/moinuflix_cache")

CACHE_DIR = get_cache_dir()
try:
    os.makedirs(CACHE_DIR, exist_ok=True)
except:
    pass

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def get_json_data(chunk_name):
    url = RAW_GITHUB + chunk_name
    cache_file = os.path.join(CACHE_DIR, chunk_name)
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"})
        with urllib.request.urlopen(req, timeout=10) as resp:
            data = json.loads(resp.read().decode("utf-8"))
            try:
                with open(cache_file, "w", encoding="utf-8") as f:
                    json.dump(data, f)
            except:
                pass
            return data
    except Exception as e:
        if os.path.exists(cache_file):
            try:
                with open(cache_file, "r", encoding="utf-8") as f:
                    return json.load(f)
            except:
                pass
    return []

# --- MAIN MENU ---
def main_menu():
    categories = [
        {"title": "[B][COLOR cyan]🔍 Search Movies & Series[/COLOR][/B]", "action": "search", "chunk": "", "icon": "DefaultAddonsSearch.png"},
        {"title": "[B][COLOR lime]🎭 Genres (Action, Horror...)[/COLOR][/B]", "action": "genres_menu", "chunk": "", "icon": "DefaultGenre.png"},
        {"title": "[B][COLOR cyan]🌴 Kollywood (Tamil)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_tamil.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR lightgreen]🏛️ Tollywood (Telugu)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_telugu.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR yellow]✨ Bollywood (Hindi)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_hindi.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR skyblue]🌐 Hollywood (English / Multi)[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01_english.json", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR gold]👑 All Movies Master[/COLOR][/B]", "action": "list_movies", "chunk": "data_c01.json", "icon": "DefaultMovies.png"},
        {"title": "[B][COLOR magenta]📺 Web Series (c02)[/COLOR][/B]", "action": "list_series", "chunk": "data_c02.json", "icon": "DefaultTVShows.png"},
        {"title": "[B][COLOR orange]🎵 5.1 Surround Songs (c03)[/COLOR][/B]", "action": "list_songs", "chunk": "data_c03.json", "icon": "DefaultAudio.png"},
        {"title": "[B][COLOR red]🍿 YouTube Vault (c04)[/COLOR][/B]", "action": "list_vault", "chunk": "data_c04.json", "icon": "DefaultVideo.png"}
    ]

    for cat in categories:
        li = xbmcgui.ListItem(label=cat["title"])
        li.setArt({"icon": cat["icon"], "thumb": cat["icon"]})
        url = build_url({"action": cat["action"], "chunk": cat["chunk"]})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)

# --- GENRES MENU ---
def show_genres():
    genres = ["Action", "Horror", "Comedy", "Thriller", "Drama", "Sci-Fi", "Crime", "Adventure", "Romance"]
    for g in genres:
        li = xbmcgui.ListItem(label=f"[B][COLOR deepskyblue]📂 {g}[/COLOR][/B]")
        li.setArt({"icon": "DefaultGenre.png", "thumb": "DefaultGenre.png"})
        url = build_url({"action": "filter_genre", "genre": g.lower()})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "genres")
    xbmcplugin.endOfDirectory(HANDLE)

def filter_by_genre(genre_name):
    movies = get_json_data("data_c01.json")
    series = get_json_data("data_c02.json")
    all_items = movies + series

    results = []
    for item in all_items:
        item_genres = [g.lower() for g in item.get("genres", [])]
        plot = item.get("plot", "").lower()
        title = (item.get("title") or item.get("name") or "").lower()

        if (genre_name in item_genres) or (genre_name in plot) or (genre_name in title):
            results.append(item)

    if not results:
        xbmcgui.Dialog().notification("MoinuFlix", f"No items found for {genre_name.title()}", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    display_mixed_results(results)

# --- SEARCH SYSTEM ---
def search_system():
    keyboard = xbmc.Keyboard("", "Search Movies & Series")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        return

    query = keyboard.getText().strip().lower()
    if not query:
        return

    movies = get_json_data("data_c01.json")
    series = get_json_data("data_c02.json")
    all_items = movies + series

    results = []
    for item in all_items:
        title = (item.get("title") or item.get("name") or "").lower()
        plot = item.get("plot", "").lower()
        if (query in title) or (query in plot):
            results.append(item)

    if not results:
        xbmcgui.Dialog().notification("MoinuFlix", "No results found!", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    display_mixed_results(results)

def display_mixed_results(items):
    for idx, item in enumerate(items):
        title = item.get("title") or item.get("name") or "Item"
        poster = item.get("poster") or ""
        fanart = item.get("fanart") or ""
        plot = item.get("plot") or ""

        if "episodes" in item or item.get("mediatype") == "tvshow":
            li = xbmcgui.ListItem(label=f"[B][COLOR magenta][TV][/COLOR] {title}[/B]")
            li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
            li.setInfo("video", {"title": title, "plot": plot, "mediatype": "tvshow", "episode": len(item.get("episodes", []))})
            url = build_url({"action": "list_episodes", "chunk": "data_c02.json", "series_index": idx, "series_id": str(item.get("id", ""))})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        else:
            li = xbmcgui.ListItem(label=f"[B][COLOR gold][Movie][/COLOR] {title}[/B]")
            li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
            li.setInfo("video", {"title": title, "plot": plot, "mediatype": "movie"})
            li.setProperty("IsPlayable", "true")
            stream_url = item.get("stream_url", "")
            url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)

# --- MOVIES LIST ---
def list_movies(chunk_file):
    movies = get_json_data(chunk_file)
    if not movies:
        xbmcgui.Dialog().notification("MoinuFlix", "Loading failed or empty chunk!", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    for idx, m in enumerate(movies):
        title = m.get("title") or m.get("name") or "Unknown"
        year = str(m.get("year", ""))
        rating = str(m.get("rating", "7.5"))
        poster = m.get("poster") or ""
        fanart = m.get("fanart") or ""
        plot = m.get("plot") or ""

        specs = m.get("specs") or {}
        source = specs.get("source", "WEB-DL")
        langs = specs.get("languages", "")

        is_multi = ("," in langs) or ("multi" in (m.get("name", "").lower()))
        multi_tag = " [COLOR gold][MULTI][/COLOR]" if is_multi else ""
        ott_tag = f" [COLOR red][{source}][/COLOR]" if source in ["Netflix", "Disney+ Hotstar", "SonyLIV", "Prime Video"] else ""

        display_label = f"{title} ({year}){ott_tag}{multi_tag}"
        li = xbmcgui.ListItem(label=display_label)
        li.setArt({"thumb": poster, "poster": poster, "fanart": fanart, "icon": "DefaultMovies.png"})

        try:
            info = {
                "title": title,
                "year": int(year) if year.isdigit() else 0,
                "rating": float(rating) if rating.replace('.', '', 1).isdigit() else 7.0,
                "plot": plot,
                "mediatype": "movie"
            }
            li.setInfo("video", info)
        except:
            pass

        url = build_url({"action": "play_movie", "chunk": chunk_file, "movie_index": idx})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "movies")
    xbmcplugin.endOfDirectory(HANDLE)

# --- WEB SERIES LIST (SHOWS) ---
def list_series(chunk_file):
    series = get_json_data(chunk_file)
    for idx, s in enumerate(series):
        title = s.get("title") or s.get("name") or "Series"
        poster = s.get("poster") or ""
        fanart = s.get("fanart") or ""
        logo = s.get("logo") or ""
        plot = s.get("plot") or ""
        rating = str(s.get("rating", "8.0"))
        ep_count = len(s.get("episodes", []))

        li = xbmcgui.ListItem(label=f"[B]{title}[/B] [COLOR lightgreen]({ep_count} Episodes)[/COLOR]")
        li.setArt({"thumb": poster, "poster": poster, "fanart": fanart, "clearlogo": logo, "icon": "DefaultTVShows.png"})

        li.setInfo("video", {
            "title": title,
            "plot": plot,
            "rating": float(rating) if rating.replace('.', '', 1).isdigit() else 8.0,
            "mediatype": "tvshow",
            "episode": ep_count,
            "totalepisodes": ep_count
        })

        url = build_url({"action": "list_episodes", "chunk": chunk_file, "series_index": idx, "series_id": str(s.get("id", ""))})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(HANDLE)

# --- EPISODES LIST (EPISODE 1, 2, 3...) ---
def list_episodes(chunk_file, series_index, series_id):
    series_list = get_json_data(chunk_file)
    target_series = None

    if series_id:
        for s in series_list:
            if str(s.get("id")) == str(series_id):
                target_series = s
                break

    if not target_series and series_index is not None and series_index < len(series_list):
        target_series = series_list[series_index]

    if not target_series or "episodes" not in target_series:
        xbmcgui.Dialog().notification("MoinuFlix", "No episodes found!", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    episodes = target_series.get("episodes", [])
    series_fanart = target_series.get("fanart", "")

    for ep in episodes:
        ep_num = ep.get("episode", 1)
        season_num = ep.get("season", 1)
        ep_title = ep.get("title", f"Episode {ep_num}")
        label_text = f"[COLOR cyan]S{season_num:02d}E{ep_num:02d}[/COLOR] - {ep_title}"

        li = xbmcgui.ListItem(label=label_text)
        thumb = ep.get("thumb") or ep.get("fanart") or series_fanart
        fanart = ep.get("fanart") or series_fanart

        li.setArt({
            "thumb": thumb,
            "poster": target_series.get("poster", ""),
            "fanart": fanart,
            "icon": "DefaultVideo.png"
        })

        li.setInfo("video", {
            "title": ep_title,
            "season": season_num,
            "episode": ep_num,
            "plot": ep.get("plot", ""),
            "mediatype": "episode",
            "tvshowtitle": target_series.get("title", "")
        })

        li.setProperty("IsPlayable", "true")
        stream_url = ep.get("stream_url", "")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": ep_title})

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "episodes")
    xbmcplugin.endOfDirectory(HANDLE)

# --- 5.1 SONGS (ALBUM / PACK LEVEL) ---
def list_songs(chunk_file):
    songs_data = get_json_data(chunk_file)
    for idx, s in enumerate(songs_data):
        title = s.get("title") or s.get("name") or "5.1 Surround Album"
        movie = s.get("movie") or ""
        poster = s.get("poster") or ""
        fanart = s.get("fanart") or ""
        tracks = s.get("episodes") or s.get("tracks") or s.get("songs") or []

        if tracks:
            # Agar series jaisa pack hai toh folder banega
            track_count = len(tracks)
            label = f"[B]{title}[/B]" + (f" [COLOR orange]({movie})[/COLOR]" if movie else "") + f" [COLOR lightgreen]({track_count} Tracks)[/COLOR]"
            li = xbmcgui.ListItem(label=label)
            li.setArt({"thumb": poster, "poster": poster, "fanart": fanart, "icon": "DefaultAudio.png"})
            li.setInfo("video", {"title": title, "plot": s.get("plot", ""), "mediatype": "musicvideo"})
            url = build_url({"action": "list_song_tracks", "chunk": chunk_file, "song_index": idx, "song_id": str(s.get("id", ""))})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
        else:
            # Agar single direct playable song hai
            stream_url = s.get("stream_url") or ""
            label = f"[B]{title}[/B]" + (f" [COLOR orange]({movie})[/COLOR]" if movie else "")
            li = xbmcgui.ListItem(label=label)
            li.setArt({"thumb": poster, "fanart": fanart, "icon": "DefaultAudio.png"})
            li.setProperty("IsPlayable", "true")
            url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
            xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.endOfDirectory(HANDLE)

# --- 5.1 SONGS (INDIVIDUAL TRACKS LIST) ---
def list_song_tracks(chunk_file, song_index, song_id):
    songs_data = get_json_data(chunk_file)
    target = None

    if song_id:
        for s in songs_data:
            if str(s.get("id")) == str(song_id):
                target = s
                break

    if not target and song_index is not None and song_index < len(songs_data):
        target = songs_data[song_index]

    tracks = target.get("episodes") or target.get("tracks") or target.get("songs") or []
    if not tracks:
        xbmcgui.Dialog().notification("MoinuFlix", "No tracks found in album!", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(HANDLE)
        return

    album_art = target.get("poster") or target.get("fanart") or ""

    for idx, tr in enumerate(tracks):
        track_title = tr.get("title") or tr.get("name") or f"Track {idx + 1}"
        specs = tr.get("specs") or {}
        channels = specs.get("channels") or "5.1"
        audio_codec = specs.get("audio") or "Surround"

        label = f"[COLOR gold]🎵 {track_title}[/COLOR] [COLOR skyblue][{audio_codec} {channels}][/COLOR]"
        li = xbmcgui.ListItem(label=label)
        thumb = tr.get("thumb") or tr.get("poster") or album_art
        fanart = tr.get("fanart") or album_art

        li.setArt({"thumb": thumb, "poster": album_art, "fanart": fanart, "icon": "DefaultAudio.png"})
        li.setInfo("video", {
            "title": track_title,
            "plot": tr.get("plot", ""),
            "mediatype": "musicvideo"
        })

        li.setProperty("IsPlayable", "true")
        stream_url = tr.get("stream_url", "")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": track_title})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(HANDLE, "songs")
    xbmcplugin.endOfDirectory(HANDLE)

# --- PLAYERS ---
def play_movie(chunk_file, movie_index):
    movies = get_json_data(chunk_file)
    if movie_index >= len(movies):
        return
    movie = movies[movie_index]
    versions = movie.get("versions") or []
    stream_url = movie.get("stream_url", "")

    if len(versions) > 1:
        labels = []
        for v in versions:
            q = v.get("quality") or v.get("resolution") or "Standard"
            src = v.get("source") or "WEB-DL"
            aud = v.get("audio") or ""
            sz = (v.get("specs") or {}).get("size")
            size_txt = f" [{sz}]" if sz else ""
            labels.append(f"{q} • {src} • {aud}{size_txt}")

        dialog = xbmcgui.Dialog()
        sel = dialog.select("Select Quality Version", labels)
        if sel < 0:
            return
        stream_url = versions[sel].get("stream_url") or stream_url
    elif len(versions) == 1:
        stream_url = versions[0].get("stream_url") or stream_url

    play_direct(stream_url, movie.get("title", "Movie"))

def play_direct(stream_url, title=""):
    if not stream_url:
        xbmcgui.Dialog().notification("MoinuFlix", "No Stream URL found", xbmcgui.NOTIFICATION_ERROR)
        return
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setInfo("video", {"title": title})
    xbmcplugin.setResolvedUrl(HANDLE, True, play_item)

def list_vault(chunk_file):
    vault = get_json_data(chunk_file)
    for v in vault:
        title = v.get("title") or "Vault Video"
        thumb = v.get("thumbnail") or ""
        stream_url = v.get("stream_url") or ""
        li = xbmcgui.ListItem(label=f"[COLOR red]{title}[/COLOR]")
        li.setArt({"thumb": thumb, "icon": "DefaultVideo.png"})
        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(HANDLE, "videos")
    xbmcplugin.endOfDirectory(HANDLE)

# --- ROUTER ---
def router():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and len(sys.argv[2]) > 1 else ""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    chunk = params.get("chunk", "")

    if not action:
        main_menu()
    elif action == "search":
        search_system()
    elif action == "genres_menu":
        show_genres()
    elif action == "filter_genre":
        filter_by_genre(params.get("genre", ""))
    elif action == "list_movies":
        list_movies(chunk)
    elif action == "play_movie":
        play_movie(chunk, int(params.get("movie_index", 0)))
    elif action == "list_series":
        list_series(chunk)
    elif action == "list_episodes":
        s_idx = int(params.get("series_index")) if params.get("series_index") is not None else None
        list_episodes(chunk, s_idx, params.get("series_id"))
    elif action == "list_songs":
        list_songs(chunk)
    elif action == "list_song_tracks":
        s_idx = int(params.get("song_index")) if params.get("song_index") is not None else None
        list_song_tracks(chunk, s_idx, params.get("song_id"))
    elif action == "play_direct":
        play_direct(params.get("stream_url", ""), params.get("title", ""))
    elif action == "list_vault":
        list_vault(chunk)

if __name__ == "__main__":
    router()
