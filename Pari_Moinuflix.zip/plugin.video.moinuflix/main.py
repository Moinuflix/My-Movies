# -*- coding: utf-8 -*-
import sys, os, json, urllib.parse, urllib.request, base64, time
import xbmc, xbmcgui, xbmcplugin

BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
REPO_API = "https://api.github.com/repos/Moinuflix/My-Movies/contents/chunks/"
CUSTOM_UA = "Kodi-MoinuTV-PrivatePlayer/1.0"
WORKER_BASE = "https://gdrive-stream.moinudeentv.workers.dev/?id="

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def get_json_data(chunk_name):
    if not chunk_name:
        return []
    api_url = f"{REPO_API}{chunk_name}?t={int(time.time())}"
    try:
        req = urllib.request.Request(api_url, headers={
            "User-Agent": CUSTOM_UA,
            "Accept": "application/vnd.github.v3+json",
            "Cache-Control": "no-cache"
        })
        with urllib.request.urlopen(req, timeout=8) as resp:
            meta = json.loads(resp.read().decode("utf-8"))
            content_b64 = meta.get("content", "")
            raw_text = base64.b64decode(content_b64).decode("utf-8")
            data = json.loads(raw_text)
            if isinstance(data, list):
                return data
    except Exception as e:
        xbmc.log(f"[MoinuFlix] GitHub API error: {e}", xbmc.LOGWARNING)
    return []

def main_menu():
    categories = [
        {"title": "[B][COLOR cyan]🔍 Search MoinuFlix...[/COLOR][/B]", "action": "search_global", "lang": "", "icon": "DefaultAddonsSearch.png"},
        {"title": "[B][COLOR gold]🔥 Master Movies Library[/COLOR][/B]", "action": "list_movies", "lang": "all", "icon": "DefaultMovies.png"},
        {"title": "[B][COLOR orange]🎵 5.1 Surround Master Video Tracks[/COLOR][/B]", "action": "list_songs", "lang": "", "icon": "DefaultMusicVideos.png"},
        {"title": "[B][COLOR springgreen]📺 Web Series Hub[/COLOR][/B]", "action": "list_series", "lang": "", "icon": "DefaultTVShows.png"},
        {"title": "[B][COLOR cyan]🌴 Kollywood (Tamil)[/COLOR][/B]", "action": "list_movies", "lang": "ta", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR lightgreen]🏛️ Tollywood (Telugu)[/COLOR][/B]", "action": "list_movies", "lang": "te", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR yellow]✨ Bollywood (Hindi)[/COLOR][/B]", "action": "list_movies", "lang": "hi", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR skyblue]🗽 Hollywood (English)[/COLOR][/B]", "action": "list_movies", "lang": "en", "icon": "DefaultFolder.png"},
    ]
    for cat in categories:
        li = xbmcgui.ListItem(label=cat["title"])
        li.setArt({"icon": cat["icon"], "thumb": cat["icon"]})
        url = build_url({"action": cat["action"], "lang": cat.get("lang", "")})
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def list_movies(filter_lang="all"):
    # First priority: check specific chunk file if exists, else load master data_c01.json
    movies = []
    chunk_map = {"ta": "data_c01_tamil.json", "te": "data_c01_telugu.json", "hi": "data_c01_hindi.json", "en": "data_c01_english.json"}
    
    if filter_lang in chunk_map:
        movies = get_json_data(chunk_map[filter_lang])

    # Agar specific file empty hai, toh Master file se auto-filter karein
    if not movies:
        master_movies = get_json_data("data_c01.json")
        if filter_lang == "all" or not filter_lang:
            movies = master_movies
        else:
            for m in master_movies:
                orig_lang = (m.get("original_language") or "").lower()
                specs_lang = (m.get("specs", {}).get("languages") or "").lower()
                name_field = (m.get("name") or "").lower()
                
                lang_matches = {
                    "ta": ["ta", "tamil"],
                    "te": ["te", "telugu"],
                    "hi": ["hi", "hindi"],
                    "en": ["en", "english"]
                }
                targets = lang_matches.get(filter_lang, [filter_lang])
                
                if orig_lang in targets or any(t in specs_lang for t in targets) or any(t in name_field for t in targets):
                    movies.append(m)

    xbmcplugin.setContent(HANDLE, "movies")
    if not movies:
        xbmcgui.Dialog().notification("MoinuFlix", f"No movies found for selected category", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return

    for m in movies:
        title = m.get("title") or m.get("name") or "Movie"
        year = str(m.get("year", ""))
        display_label = f"[B]{title}[/B]"
        if year:
            display_label += f" [COLOR gray]({year})[/COLOR]"

        stream_url = m.get("stream_url", "")
        if not stream_url and m.get("id"):
            stream_url = f"{WORKER_BASE}{m.get('id')}|User-Agent={CUSTOM_UA}"
        elif not stream_url and m.get("versions"):
            v0 = m["versions"][0]
            stream_url = v0.get("stream_url", "")
            if not stream_url and v0.get("id"):
                stream_url = f"{WORKER_BASE}{v0.get('id')}|User-Agent={CUSTOM_UA}"

        li = xbmcgui.ListItem(label=display_label)
        poster = m.get("poster", "")
        fanart = m.get("fanart", "")
        clearlogo = m.get("clearlogo") or m.get("logo") or ""

        art_dict = {"poster": poster, "thumb": poster, "fanart": fanart}
        if clearlogo:
            art_dict["clearlogo"] = clearlogo
            art_dict["logo"] = clearlogo
        li.setArt(art_dict)

        info = li.getVideoInfoTag()
        info.setTitle(title)
        info.setPlot(m.get("plot", ""))
        if year.isdigit():
            info.setYear(int(year))
        if m.get("rating"):
            try:
                info.setRating(float(m.get("rating")))
            except:
                pass

        li.setProperty("IsPlayable", "true")
        url = build_url({
            "action": "play_direct",
            "stream_url": stream_url,
            "title": title,
            "poster": poster,
            "fanart": fanart
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def list_series():
    series_list = get_json_data("data_c02.json")
    xbmcplugin.setContent(HANDLE, "tvshows")
    if not series_list:
        xbmcgui.Dialog().notification("MoinuFlix", "No Series Found", xbmcgui.NOTIFICATION_INFO, 1500)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)
        return
    for s in series_list:
        title = s.get("title") or s.get("name") or "Web Series"
        ep_count = len(s.get("episodes", []))
        year = str(s.get("year", ""))
        display_label = f"[COLOR springgreen]📁[/COLOR] [B]{title}[/B]"
        if ep_count:
            display_label += f" [COLOR lime]({ep_count} Episodes)[/COLOR]"
        if year:
            display_label += f" [COLOR gray]({year})[/COLOR]"

        poster = s.get("poster", "")
        fanart = s.get("fanart", "")
        clearlogo = s.get("clearlogo") or s.get("logo") or ""

        li = xbmcgui.ListItem(label=display_label)
        art_dict = {"thumb": poster, "poster": poster, "fanart": fanart, "icon": "DefaultFolder.png"}
        if clearlogo:
            art_dict["clearlogo"] = clearlogo
            art_dict["logo"] = clearlogo
        li.setArt(art_dict)

        info = li.getVideoInfoTag()
        info.setTitle(title)
        info.setPlot(s.get("plot", ""))

        s_id = str(s.get("id") or s.get("tmdb_id") or title)
        url = build_url({
            "action": "list_series_episodes",
            "series_id": s_id
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def list_series_episodes(series_id):
    series_list = get_json_data("data_c02.json")
    xbmcplugin.setContent(HANDLE, "episodes")
    target_series = None
    for s in series_list:
        sid = str(s.get("id", ""))
        tmdb_id = str(s.get("tmdb_id", ""))
        title = str(s.get("title", ""))
        req_id = str(series_id or "")
        if req_id and (req_id == sid or req_id == tmdb_id or req_id == title):
            target_series = s
            break

    if not target_series:
        xbmcgui.Dialog().notification("MoinuFlix", "Series Not Found", xbmcgui.NOTIFICATION_WARNING, 2000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return

    episodes = target_series.get("episodes", [])
    clearlogo = target_series.get("clearlogo") or target_series.get("logo") or ""

    for idx, ep in enumerate(episodes, 1):
        ep_title = ep.get("title") or ep.get("name") or f"Episode {idx}"
        ep_num = ep.get("episode_number") or ep.get("episode") or idx
        season_num = ep.get("season_number") or ep.get("season") or 1
        label = f"[COLOR cyan]▶[/COLOR] [B]S{int(season_num):02d}E{int(ep_num):02d}[/B] - {ep_title}"

        stream_url = ep.get("stream_url", "")
        if not stream_url and ep.get("id"):
            stream_url = f"{WORKER_BASE}{ep.get('id')}|User-Agent={CUSTOM_UA}"

        thumb = ep.get("thumb") or ep.get("still_path") or target_series.get("fanart", "")
        poster = target_series.get("poster", "")

        li = xbmcgui.ListItem(label=label)
        art_dict = {"thumb": thumb, "poster": poster, "fanart": target_series.get("fanart", "")}
        if clearlogo:
            art_dict["clearlogo"] = clearlogo
            art_dict["logo"] = clearlogo
        li.setArt(art_dict)

        info = li.getVideoInfoTag()
        info.setTitle(ep_title)
        info.setPlot(ep.get("plot", "") or target_series.get("plot", ""))
        try:
            info.setSeason(int(season_num))
            info.setEpisode(int(ep_num))
        except:
            pass

        li.setProperty("IsPlayable", "true")
        url = build_url({
            "action": "play_direct",
            "stream_url": stream_url,
            "title": f"{target_series.get('title')} - S{int(season_num):02d}E{int(ep_num):02d}",
            "poster": poster,
            "fanart": target_series.get("fanart", "")
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def list_songs():
    albums = get_json_data("data_c03.json")
    xbmcplugin.setContent(HANDLE, "musicvideos")
    for alb in albums:
        title = alb.get("title") or alb.get("movie") or "5.1 Soundtrack Album"
        tracks_count = len(alb.get("tracks", []))
        poster = alb.get("poster", "")
        fanart = alb.get("fanart", "")
        clearlogo = alb.get("clearlogo") or alb.get("logo") or ""

        display_label = f"[COLOR orange]📁[/COLOR] [B]{title}[/B] [COLOR lime]({tracks_count} Tracks)[/COLOR]"
        li = xbmcgui.ListItem(label=display_label)
        art_dict = {"thumb": poster, "poster": poster, "fanart": fanart, "icon": "DefaultFolder.png"}
        if clearlogo:
            art_dict["clearlogo"] = clearlogo
            art_dict["logo"] = clearlogo
        li.setArt(art_dict)

        alb_identifier = str(alb.get("id") or alb.get("tmdb_id") or title)
        url = build_url({
            "action": "list_album_tracks",
            "album_id": alb_identifier
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def list_album_tracks(album_id):
    albums = get_json_data("data_c03.json")
    xbmcplugin.setContent(HANDLE, "musicvideos")
    target_album = None
    for alb in albums:
        a_id = str(alb.get("id", ""))
        tmdb_id = str(alb.get("tmdb_id", ""))
        title = str(alb.get("title", ""))
        req_id = str(album_id or "")
        if req_id and (req_id == a_id or req_id == tmdb_id or req_id == title):
            target_album = alb
            break
    if not target_album:
        xbmcgui.Dialog().notification("MoinuFlix", "Album Not Found", xbmcgui.NOTIFICATION_WARNING, 2000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    tracks = target_album.get("tracks", [])
    clearlogo = target_album.get("clearlogo") or target_album.get("logo") or ""

    for idx, t in enumerate(tracks, 1):
        title = t.get("title", f"Track {idx}")
        audio = t.get("specs", {}).get("audio", "5.1 Surround")
        artist = t.get("artist", "")
        label = f"[COLOR cyan]♬[/COLOR] [B]{title}[/B] [COLOR gold]({audio})[/COLOR]"
        if artist:
            label += f" [COLOR gray]- {artist}[/COLOR]"
        stream_url = t.get("stream_url", "")
        if not stream_url and t.get("id"):
            stream_url = f"{WORKER_BASE}{t.get('id')}|User-Agent={CUSTOM_UA}"
        poster = t.get("thumb") or target_album.get("poster", "")
        fanart = t.get("fanart") or target_album.get("fanart", "")

        li = xbmcgui.ListItem(label=label)
        art_dict = {"thumb": poster, "poster": poster, "fanart": fanart}
        if clearlogo:
            art_dict["clearlogo"] = clearlogo
            art_dict["logo"] = clearlogo
        li.setArt(art_dict)

        li.setProperty("IsPlayable", "true")
        url = build_url({
            "action": "play_direct",
            "stream_url": stream_url,
            "title": title,
            "poster": poster,
            "fanart": fanart
        })
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def search_global():
    kb = xbmc.Keyboard("", "Search MoinuFlix Movies, Series & Songs")
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False, cacheToDisc=False)
        return
    query = kb.getText().strip().lower()

    xbmcplugin.setContent(HANDLE, "movies")
    chunks = ["data_c01.json", "data_c02.json", "data_c03.json"]
    found_count = 0

    for ch in chunks:
        items = get_json_data(ch)
        for item in items:
            title = (item.get("title") or item.get("name") or "").strip()
            if query in title.lower():
                found_count += 1
                stream_url = item.get("stream_url", "")
                if not stream_url and item.get("id"):
                    stream_url = f"{WORKER_BASE}{item.get('id')}|User-Agent={CUSTOM_UA}"
                elif not stream_url and item.get("versions"):
                    stream_url = item["versions"][0].get("stream_url", "")
                    if not stream_url and item["versions"][0].get("id"):
                        stream_url = f"{WORKER_BASE}{item['versions'][0].get('id')}|User-Agent={CUSTOM_UA}"

                tag = "🎬 [MOVIE]" if "c01" in ch else ("📺 [SERIES]" if "c02" in ch else "🎵 [SONG]")
                label = f"{tag} [B]{title}[/B]"

                poster = item.get("poster", "")
                fanart = item.get("fanart", "")
                clearlogo = item.get("clearlogo") or item.get("logo") or ""

                li = xbmcgui.ListItem(label=label)
                art_dict = {"poster": poster, "thumb": poster, "fanart": fanart}
                if clearlogo:
                    art_dict["clearlogo"] = clearlogo
                    art_dict["logo"] = clearlogo
                li.setArt(art_dict)

                if "c02" in ch:
                    url = build_url({"action": "list_series_episodes", "series_id": str(item.get("id") or item.get("tmdb_id") or title)})
                    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
                elif "c03" in ch:
                    url = build_url({"action": "list_album_tracks", "album_id": str(item.get("id") or item.get("tmdb_id") or title)})
                    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
                else:
                    li.setProperty("IsPlayable", "true")
                    url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title, "poster": poster, "fanart": fanart})
                    xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=False)

    if found_count == 0:
        xbmcgui.Dialog().notification("MoinuFlix Search", f"No results for: {query}", xbmcgui.NOTIFICATION_INFO, 2000)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True, cacheToDisc=False)

def play_direct(stream_url, title="", poster="", fanart=""):
    if not stream_url:
        xbmcgui.Dialog().notification("MoinuFlix", "Stream URL Missing", xbmcgui.NOTIFICATION_ERROR, 2500)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    info = play_item.getVideoInfoTag()
    info.setTitle(title)
    xbmcplugin.setResolvedUrl(HANDLE, True, play_item)

def router():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and len(sys.argv[2]) > 1 else ""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    lang = params.get("lang", "all")
    
    if not action:
        main_menu()
    elif action == "search_global":
        search_global()
    elif action == "list_movies":
        list_movies(lang)
    elif action == "list_series":
        list_series()
    elif action == "list_series_episodes":
        list_series_episodes(params.get("series_id"))
    elif action == "list_songs":
        list_songs()
    elif action == "list_album_tracks":
        list_album_tracks(params.get("album_id"))
    elif action == "play_direct":
        play_direct(
            params.get("stream_url", ""),
            params.get("title", ""),
            params.get("poster", ""),
            params.get("fanart", "")
        )

if __name__ == "__main__":
    router()
