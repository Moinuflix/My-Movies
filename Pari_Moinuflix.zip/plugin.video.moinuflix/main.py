# -*- coding: utf-8 -*-
import sys, urllib.parse
import xbmcgui, xbmcplugin
from resources.lib.api import get_handle, build_url, play_direct
from resources.lib.movies import list_movies
from resources.lib.series import list_series, list_series_episodes
from resources.lib.songs import list_songs, list_album_tracks
from resources.lib.search import search_global
from resources.lib.youtube import youtube_search_ui, youtube_feed_ui

def main_menu():
    handle = get_handle()
    categories = [
        {"title": "[B][COLOR cyan]🔍 Search MoinuFlix...[/COLOR][/B]", "action": "search_global", "lang": "", "icon": "DefaultAddonsSearch.png"},
        {"title": "[B][COLOR red]▶ YouTube: Live Direct Search[/COLOR][/B]", "action": "yt_search", "lang": "", "icon": "DefaultAddonsSearch.png"},
        {"title": "[B][COLOR red]🔥 YouTube: Trending & Music[/COLOR][/B]", "action": "yt_feed", "lang": "", "icon": "DefaultVideo.png"},
        {"title": "[B][COLOR gold]🔥 Master Movies Library[/COLOR][/B]", "action": "list_movies", "lang": "all", "icon": "DefaultMovies.png"},
        {"title": "[B][COLOR orange]🎵 5.1 Surround Master Video Tracks[/COLOR][/B]", "action": "list_songs", "lang": "", "icon": "DefaultMusicVideos.png"},
        {"title": "[B][COLOR springgreen]📺 Web Series Hub[/COLOR][/B]", "action": "list_series", "lang": "", "icon": "DefaultTVShows.png"},
        {"title": "[B][COLOR cyan]🌴 Kollywood (Tamil)[/COLOR][/B]", "action": "list_movies", "lang": "ta", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR lightgreen]🏛️ Tollywood (Telugu)[/COLOR][/B]", "action": "list_movies", "lang": "te", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR yellow]✨ Bollywood (Hindi)[/COLOR][/B]", "action": "list_movies", "lang": "hi", "icon": "DefaultFolder.png"},
        {"title": "[B][COLOR skyblue]🗽 Hollywood (English)[/COLOR][/B]", "action": "list_movies", "lang": "en", "icon": "DefaultFolder.png"},
    ]
    for cat in categories:
        li = xbmcgui.ListItem(label=cat["title"])
        li.setArt({"icon": cat["icon"], "thumb": cat["icon"]})
        url = build_url({"action": cat["action"], "lang": cat.get("lang", "")})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def router():
    paramstring = sys.argv[2][1:] if len(sys.argv) > 2 and len(sys.argv[2]) > 1 else ""
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get("action")
    lang = params.get("lang", "all")
    
    if not action:
        main_menu()
    elif action == "yt_search":
        youtube_search_ui()
    elif action == "yt_feed":
        youtube_feed_ui()
    elif action == "search_global":
        search_global()
    elif action == "list_movies":
        list_movies(lang)
    elif action == "list_series":
        list_series()
    elif action == "list_series_episodes":
        list_series_episodes(params.get("series_id"))
    elif action == "list_songs":
        list_songs()
    elif action == "list_album_tracks":
        list_album_tracks(params.get("album_id"))
    elif action == "play_direct":
        play_direct(params.get("stream_url", ""), params.get("title", ""), params.get("poster", ""), params.get("fanart", ""))

if __name__ == "__main__":
    router()
