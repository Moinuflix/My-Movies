# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin

try:
    ADDON_HANDLE = int(sys.argv[1])
except:
    ADDON_HANDLE = 0

BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
REPO_RAW_BASE = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks/"
USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64)"

def build_url(query):
    return BASE_URL + "?" + urllib.parse.urlencode(query)

def fetch_json_chunk(filename):
    url = REPO_RAW_BASE + filename
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(req, timeout=10) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception as e:
        xbmc.log("[MoinuFlix] Error loading " + filename + ": " + str(e), xbmc.LOGERROR)
        return []

def show_main_menu():
    categories = [
        ("🎬 Movies", "list_movies", "4K UHD, 1080p FHD & Multi-Audio Movies"),
        ("📺 Web Series", "list_series", "TV Shows, Seasons & Episode Library"),
        ("🎵 5.1 / Atmos Songs", "list_songs", "Dolby Atmos 7.1, 5.1 Surround & FLAC Music"),
        ("🍿 YouTube Vault", "list_vault", "Comedy Scenes, Action & Video Songs")
    ]
    for title, mode, desc in categories:
        li = xbmcgui.ListItem(label=title)
        li.setInfo("video", {"title": title, "plot": desc})
        url = build_url({"mode": mode})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_movies():
    movies = fetch_json_chunk("data_c01.json")
    for movie in movies:
        title = movie.get("title", movie.get("name", "Movie"))
        year = int(movie.get("year", 0)) if str(movie.get("year", 0)).isdigit() else 0
        rating = float(movie.get("rating", 7.0)) if str(movie.get("rating", "")).replace(".","",1).isdigit() else 7.0
        plot = movie.get("plot", "")
        poster = movie.get("poster", "")
        fanart = movie.get("fanart", "")
        versions = movie.get("versions", [])

        v_count = len(versions) if versions else 1
        label = f"{title} ({year})" if v_count <= 1 else f"{title} ({year}) [{v_count} Qualities]"

        li = xbmcgui.ListItem(label=label)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "year": year, "rating": rating, "plot": plot, "mediatype": "movie"})
        li.setProperty("IsPlayable", "true")

        url = build_url({"mode": "play_movie", "tmdb_id": str(movie.get("tmdb_id", ""))})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "movies")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def play_movie(tmdb_id):
    movies = fetch_json_chunk("data_c01.json")
    movie = next((m for m in movies if str(m.get("tmdb_id", "")) == str(tmdb_id)), None)
    if not movie:
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
        return

    versions = movie.get("versions", [])
    chosen_stream = ""

    if not versions or len(versions) <= 1:
        chosen_stream = movie.get("stream_url", "")
        if versions and "stream_url" in versions[0]:
            chosen_stream = versions[0]["stream_url"]
    else:
        options = []
        for v in versions:
            q = v.get("quality", "1080p")
            codec = v.get("codec", "")
            res = v.get("resolution", "")
            audio = v.get("audio", "")
            detail = " • ".join([x for x in [res, codec, audio] if x])
            options.append(f"▶ [{q}] {detail}")

        dialog = xbmcgui.Dialog()
        choice = dialog.select(f"Select Quality — {movie.get("title")}", options)
        if choice != -1:
            chosen_stream = versions[choice].get("stream_url", "")
        else:
            xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())
            return

    if chosen_stream:
        play_item = xbmcgui.ListItem(path=chosen_stream)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, play_item)
    else:
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, xbmcgui.ListItem())

def list_series():
    shows = fetch_json_chunk("data_c02.json")
    for show in shows:
        title = show.get("title", "Series")
        year = int(show.get("year", 0)) if str(show.get("year", 0)).isdigit() else 0
        poster = show.get("poster", "")
        fanart = show.get("fanart", "")
        episodes = show.get("episodes", [])
        ep_count = len(episodes) if episodes else 1

        li = xbmcgui.ListItem(label=f"{title} ({year})")
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "year": year, "plot": f"Total Episodes: {ep_count}\n\n" + show.get("plot", ""), "mediatype": "tvshow"})
        url = build_url({"mode": "list_episodes", "tmdb_id": str(show.get("tmdb_id", ""))})
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=li, isFolder=True)

    xbmcplugin.setContent(ADDON_HANDLE, "tvshows")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_episodes(tmdb_id):
    shows = fetch_json_chunk("data_c02.json")
    show = next((s for s in shows if str(s.get("tmdb_id", "")) == str(tmdb_id)), None)
    if not show:
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    episodes = show.get("episodes", [])
    poster = show.get("poster", "")
    fanart = show.get("fanart", "")

    for ep in episodes:
        title = ep.get("title", ep.get("name", "Episode"))
        season = int(ep.get("season", 1))
        episode = int(ep.get("episode", 1))
        plot = ep.get("plot", "")
        stream_url = ep.get("stream_url", "")

        li = xbmcgui.ListItem(label=title)
        li.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
        li.setInfo("video", {"title": title, "season": season, "episode": episode, "plot": plot, "mediatype": "episode"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "episodes")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_songs():
    songs = fetch_json_chunk("data_c03.json")
    for song in songs:
        title = song.get("title", "Audio Track")
        poster = song.get("poster", "")
        specs = song.get("specs", {})
        audio_name = specs.get("audio", "5.1 Surround")
        stream_url = song.get("stream_url", "")

        li = xbmcgui.ListItem(label=f"🎵 {title} [{audio_name}]")
        li.setArt({"thumb": poster, "poster": poster, "fanart": poster})
        li.setInfo("video", {"title": title, "plot": song.get("plot", "")})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def list_vault():
    vault_items = fetch_json_chunk("data_c04.json")
    for item in vault_items:
        title = item.get("title", "YouTube Clip")
        category = item.get("category", "Clip")
        thumbnail = item.get("thumbnail", "")
        stream_url = item.get("stream_url", "")

        li = xbmcgui.ListItem(label=f"[{category}] {title}")
        li.setArt({"thumb": thumbnail, "poster": thumbnail, "fanart": thumbnail})
        li.setInfo("video", {"title": title, "genre": category, "mediatype": "video"})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=stream_url, listitem=li, isFolder=False)

    xbmcplugin.setContent(ADDON_HANDLE, "videos")
    xbmcplugin.endOfDirectory(ADDON_HANDLE)

def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    mode = params.get("mode")
    if mode == "list_movies": list_movies()
    elif mode == "play_movie": play_movie(params.get("tmdb_id", ""))
    elif mode == "list_series": list_series()
    elif mode == "list_episodes": list_episodes(params.get("tmdb_id", ""))
    elif mode == "list_songs": list_songs()
    elif mode == "list_vault": list_vault()
    else: show_main_menu()

if __name__ == "__main__":
    param = sys.argv[2][1:] if len(sys.argv) > 2 and len(sys.argv[2]) > 1 else ""
    router(param)
