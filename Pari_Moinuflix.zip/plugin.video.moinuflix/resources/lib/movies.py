DEFAULT_LOGO = "https://res.cloudinary.com/dwigabwtq/image/upload/v1788716131/pari_queen_n1f5zl.png"
# -*- coding: utf-8 -*-
import xbmcgui, xbmcplugin
from .api import get_handle, build_url, get_json_data, clean_stream_url

def list_movies(filter_lang="all"):
    handle = get_handle()
    movies = []
    chunk_map = {"ta": "data_c01_tamil.json", "te": "data_c01_telugu.json", "hi": "data_c01_hindi.json", "en": "data_c01_english.json"}
    
    if filter_lang in chunk_map:
        movies = get_json_data(chunk_map[filter_lang])

    if not movies:
        master_movies = get_json_data("data_c01.json")
        if filter_lang == "all" or not filter_lang:
            movies = master_movies
        else:
            for m in master_movies:
                orig_lang = (m.get("original_language") or "").lower()
                specs_lang = (m.get("specs", {}).get("languages") or "").lower()
                name_field = (m.get("name") or "").lower()
                lang_matches = {"ta": ["ta", "tamil"], "te": ["te", "telugu"], "hi": ["hi", "hindi"], "en": ["en", "english"]}
                targets = lang_matches.get(filter_lang, [filter_lang])
                if orig_lang in targets or any(t in specs_lang for t in targets) or any(t in name_field for t in targets):
                    movies.append(m)

    xbmcplugin.setContent(handle, "movies")
    if not movies:
        xbmcgui.Dialog().notification("MoinuFlix", "Empty list", xbmcgui.NOTIFICATION_INFO, 1500)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return

    for m in movies:
        title = m.get("title") or m.get("name") or "Movie"
        year = str(m.get("year", ""))
        display_label = f"[B]{title}[/B]" + (f" [COLOR gray]({year})[/COLOR]" if year else "")
        stream_url = clean_stream_url(m)

        li = xbmcgui.ListItem(label=display_label)
        poster = m.get("poster", "")
        fanart = m.get("fanart", "")
        clearlogo = m.get("clearlogo") or m.get("logo") or DEFAULT_LOGO

        art_dict = {"poster": poster, "thumb": poster, "fanart": fanart}
        if clearlogo:
            art_dict["clearlogo"] = clearlogo
            art_dict["logo"] = clearlogo
            li.setProperty("clearlogo", clearlogo)
            art_dict["logo"] = clearlogo
        li.setArt(art_dict)

        info = li.getVideoInfoTag()
        info.setTitle(title)
        info.setPlot(m.get("plot", ""))
        if year.isdigit():
            info.setYear(int(year))

        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title, "poster": poster, "fanart": fanart})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
