# -*- coding: utf-8 -*-
import sys, json, urllib.parse, urllib.request, base64, time
import xbmc, xbmcgui, xbmcplugin

REPO_API = "https://api.github.com/repos/Moinuflix/My-Movies/contents/chunks/"
CUSTOM_UA = "Kodi-MoinuTV-PrivatePlayer/1.0"
WORKER_BASE = "https://gdrive-stream.moinudeentv.workers.dev/?id="

def get_base_url():
    return sys.argv[0] if len(sys.argv) > 0 else ""

def get_handle():
    return int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1

def build_url(query):
    return get_base_url() + "?" + urllib.parse.urlencode(query)

def get_json_data(chunk_name):
    if not chunk_name:
        return []
    api_url = f"{REPO_API}{chunk_name}?t={int(time.time())}"
    try:
        req = urllib.request.Request(api_url, headers={
            "User-Agent": CUSTOM_UA,
            "Accept": "application/vnd.github.v3+json",
            "Cache-Control": "no-cache"
        })
        with urllib.request.urlopen(req, timeout=8) as resp:
            meta = json.loads(resp.read().decode("utf-8"))
            content_b64 = meta.get("content", "")
            raw_text = base64.b64decode(content_b64).decode("utf-8")
            data = json.loads(raw_text)
            if isinstance(data, list):
                return data
    except Exception as e:
        xbmc.log(f"[MoinuFlix] API Error ({chunk_name}): {e}", xbmc.LOGWARNING)
    return []

def clean_stream_url(item):
    url = item.get("stream_url", "")
    if not url and item.get("versions"):
        url = item["versions"][0].get("stream_url", "")
        if not url and item["versions"][0].get("id"):
            url = f"{WORKER_BASE}{item['versions'][0].get('id')}"
    if not url and item.get("id"):
        url = f"{WORKER_BASE}{item.get('id')}"

    # Pure direct resolve: Double-pipe avoid karein
    if "|User-Agent=" in url:
        return url
    elif url:
        return f"{url}|User-Agent={CUSTOM_UA}"
    return ""

def play_direct(stream_url, title="", poster="", fanart=""):
    handle = get_handle()
    if not stream_url:
        xbmcgui.Dialog().notification("MoinuFlix", "Invalid URL", xbmcgui.NOTIFICATION_ERROR, 2000)
        xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        return
    play_item = xbmcgui.ListItem(path=stream_url)
    play_item.setArt({"poster": poster, "thumb": poster, "fanart": fanart})
    info = play_item.getVideoInfoTag()
    info.setTitle(title)
    xbmcplugin.setResolvedUrl(handle, True, play_item)
