DEFAULT_LOGO = "https://res.cloudinary.com/dwigabwtq/image/upload/v1788716131/pari_queen_n1f5zl.png"
# -*- coding: utf-8 -*-
import xbmcgui, xbmcplugin
from .api import get_handle, build_url, get_json_data, clean_stream_url

def list_series():
    handle = get_handle()
    series_list = get_json_data("data_c02.json")
    xbmcplugin.setContent(handle, "tvshows")
    if not series_list:
        xbmcgui.Dialog().notification("MoinuFlix", "No Series Found", xbmcgui.NOTIFICATION_INFO, 1500)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return
    for s in series_list:
        title = s.get("title") or s.get("name") or "Web Series"
        ep_count = len(s.get("episodes", []))
        year = str(s.get("year", ""))
        display_label = f"[COLOR springgreen]📁[/COLOR] [B]{title}[/B]" + (f" [COLOR lime]({ep_count} Eps)[/COLOR]" if ep_count else "")

        li = xbmcgui.ListItem(label=display_label)
        poster = s.get("poster", "")
        fanart = s.get("fanart", "")
        clearlogo = m.get("clearlogo") or m.get("logo") or DEFAULT_LOGO
        art_dict = {"thumb": poster, "poster": poster, "fanart": fanart, "icon": "DefaultFolder.png"}
        if clearlogo:
            art_dict["clearlogo"] = clearlogo
            art_dict["logo"] = clearlogo
            li.setProperty("clearlogo", clearlogo)
            art_dict["logo"] = clearlogo
        li.setArt(art_dict)

        s_id = str(s.get("id") or s.get("tmdb_id") or title)
        url = build_url({"action": "list_series_episodes", "series_id": s_id})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def list_series_episodes(series_id):
    handle = get_handle()
    series_list = get_json_data("data_c02.json")
    xbmcplugin.setContent(handle, "episodes")
    target_series = next((s for s in series_list if str(series_id) in [str(s.get("id")), str(s.get("tmdb_id")), str(s.get("title"))]), None)
    if not target_series:
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return

    for idx, ep in enumerate(target_series.get("episodes", []), 1):
        ep_title = ep.get("title") or f"Episode {idx}"
        ep_num = ep.get("episode_number") or idx
        season_num = ep.get("season_number") or 1
        label = f"[COLOR cyan]▶[/COLOR] [B]S{int(season_num):02d}E{int(ep_num):02d}[/B] - {ep_title}"
        stream_url = clean_stream_url(ep)

        li = xbmcgui.ListItem(label=label)
        thumb = ep.get("thumb") or target_series.get("fanart", "")
        li.setArt({"thumb": thumb, "poster": target_series.get("poster", ""), "fanart": target_series.get("fanart", "")})
        info = li.getVideoInfoTag()
        info.setTitle(ep_title)
        info.setPlot(ep.get("plot", "") or target_series.get("plot", ""))
        li.setProperty("IsPlayable", "true")

        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": f"{target_series.get('title')} - S{int(season_num):02d}E{int(ep_num):02d}"})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
