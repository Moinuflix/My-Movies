DEFAULT_LOGO = "https://res.cloudinary.com/dwigabwtq/image/upload/v1788716131/pari_queen_n1f5zl.png"
# -*- coding: utf-8 -*-
import xbmcgui, xbmcplugin
from .api import get_handle, build_url, get_json_data, clean_stream_url

def list_songs():
    handle = get_handle()
    albums = get_json_data("data_c03.json")
    xbmcplugin.setContent(handle, "musicvideos")
    for alb in albums:
        title = alb.get("title") or alb.get("movie") or "5.1 Soundtrack"
        tracks_count = len(alb.get("tracks", []))
        display_label = f"[COLOR orange]📁[/COLOR] [B]{title}[/B] [COLOR lime]({tracks_count} Tracks)[/COLOR]"
        li = xbmcgui.ListItem(label=display_label)
        li.setArt({"thumb": alb.get("poster", ""), "poster": alb.get("poster", ""), "fanart": alb.get("fanart", ""), "icon": "DefaultFolder.png"})
        alb_identifier = str(alb.get("id") or alb.get("tmdb_id") or title)
        url = build_url({"action": "list_album_tracks", "album_id": alb_identifier})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def list_album_tracks(album_id):
    handle = get_handle()
    albums = get_json_data("data_c03.json")
    xbmcplugin.setContent(handle, "musicvideos")
    target_album = next((a for a in albums if str(album_id) in [str(a.get("id")), str(a.get("tmdb_id")), str(a.get("title"))]), None)
    if not target_album:
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return

    for idx, t in enumerate(target_album.get("tracks", []), 1):
        title = t.get("title", f"Track {idx}")
        audio = t.get("specs", {}).get("audio", "5.1 Surround")
        label = f"[COLOR cyan]♬[/COLOR] [B]{title}[/B] [COLOR gold]({audio})[/COLOR]"
        stream_url = clean_stream_url(t)

        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": t.get("thumb") or target_album.get("poster", ""), "poster": target_album.get("poster", ""), "fanart": target_album.get("fanart", "")})
        li.setProperty("IsPlayable", "true")
        url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
