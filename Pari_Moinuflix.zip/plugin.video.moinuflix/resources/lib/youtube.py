# -*- coding: utf-8 -*-
import sys, json, urllib.parse, urllib.request, re
import xbmc, xbmcgui, xbmcplugin
from .api import get_handle, build_url

CUSTOM_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"

def fetch_youtube_results(query):
    encoded_q = urllib.parse.quote(query)
    search_url = f"https://www.youtube.com/results?search_query={encoded_q}"
    req = urllib.request.Request(search_url, headers={"User-Agent": CUSTOM_UA})
    try:
        with urllib.request.urlopen(req, timeout=9) as resp:
            html = resp.read().decode("utf-8", errors="ignore")
            match = re.search(r"var ytInitialData\s*=\s*({.*?});</script>", html)
            if not match:
                match = re.search(r"window\[\"ytInitialData\"\]\s*=\s*({.*?});", html)
            if match:
                data = json.loads(match.group(1))
                sections = data.get("contents", {}).get("twoColumnSearchResultsRenderer", {}).get("primaryContents", {}).get("sectionListRenderer", {}).get("contents", [])
                results = []
                for s in sections:
                    items = s.get("itemSectionRenderer", {}).get("contents", [])
                    for itm in items:
                        vr = itm.get("videoRenderer")
                        if vr:
                            vid = vr.get("videoId")
                            title = vr.get("title", {}).get("runs", [{}])[0].get("text", "YouTube Video")
                            thumb = f"https://img.youtube.com/vi/{vid}/hqdefault.jpg"
                            duration = vr.get("lengthText", {}).get("simpleText", "")
                            channel = vr.get("ownerText", {}).get("runs", [{}])[0].get("text", "")
                            results.append({
                                "id": vid,
                                "title": title,
                                "thumb": thumb,
                                "duration": duration,
                                "channel": channel
                            })
                return results
    except Exception as e:
        xbmc.log(f"[MoinuFlix YouTube Error] {e}", xbmc.LOGERROR)
    return []

def youtube_search_ui():
    handle = get_handle()
    kb = xbmc.Keyboard("", "Type to Search YouTube Live...")
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    query = kb.getText().strip()
    xbmcplugin.setContent(handle, "videos")
    
    results = fetch_youtube_results(query)
    if not results:
        xbmcgui.Dialog().notification("YouTube", "No videos found", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
        return

    for v in results:
        label = f"[COLOR red]▶[/COLOR] [B]{v['title']}[/B] [COLOR gray]({v['duration']})[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": v["thumb"], "poster": v["thumb"], "fanart": v["thumb"]})
        info = li.getVideoInfoTag()
        info.setTitle(v["title"])
        info.setPlot(f"Channel: {v['channel']}")
        li.setProperty("IsPlayable", "true")

        play_url = f"plugin://plugin.video.youtube/play/?video_id={v['id']}"
        url = build_url({"action": "play_direct", "stream_url": play_url, "title": v["title"], "poster": v["thumb"], "fanart": v["thumb"]})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)

def youtube_feed_ui():
    handle = get_handle()
    xbmcplugin.setContent(handle, "videos")
    results = fetch_youtube_results("Tamil Telugu Hindi latest songs trailer")
    for v in results:
        label = f"[COLOR red]▶[/COLOR] [B]{v['title']}[/B] [COLOR gray]({v['duration']})[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"thumb": v["thumb"], "poster": v["thumb"], "fanart": v["thumb"]})
        info = li.getVideoInfoTag()
        info.setTitle(v["title"])
        info.setPlot(f"Channel: {v['channel']}")
        li.setProperty("IsPlayable", "true")

        play_url = f"plugin://plugin.video.youtube/play/?video_id={v['id']}"
        url = build_url({"action": "play_direct", "stream_url": play_url, "title": v["title"], "poster": v["thumb"], "fanart": v["thumb"]})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
