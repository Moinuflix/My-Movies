# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcplugin
from .api import get_handle, build_url, get_json_data, clean_stream_url

def search_global():
    handle = get_handle()
    kb = xbmc.Keyboard("", "Search MoinuFlix")
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(handle, succeeded=False, cacheToDisc=False)
        return
    query = kb.getText().strip().lower()

    xbmcplugin.setContent(handle, "movies")
    chunks = ["data_c01.json", "data_c02.json", "data_c03.json"]
    for ch in chunks:
        for item in get_json_data(ch):
            title = (item.get("title") or item.get("name") or "").strip()
            if query in title.lower():
                stream_url = clean_stream_url(item)
                tag = "🎬" if "c01" in ch else ("📺" if "c02" in ch else "🎵")
                li = xbmcgui.ListItem(label=f"{tag} [B]{title}[/B]")
                li.setArt({"poster": item.get("poster", ""), "thumb": item.get("poster", ""), "fanart": item.get("fanart", "")})
                if "c02" in ch:
                    url = build_url({"action": "list_series_episodes", "series_id": str(item.get("id") or title)})
                    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
                elif "c03" in ch:
                    url = build_url({"action": "list_album_tracks", "album_id": str(item.get("id") or title)})
                    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
                else:
                    li.setProperty("IsPlayable", "true")
                    url = build_url({"action": "play_direct", "stream_url": stream_url, "title": title})
                    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, succeeded=True, cacheToDisc=False)
