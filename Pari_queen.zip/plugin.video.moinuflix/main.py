# -*- coding: utf-8 -*-
import sys
import json
import urllib.request
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin

HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else 0
REPO_RAW = "https://raw.githubusercontent.com/Moinuflix/My-Movies/main/chunks"
USER_AGENT = "Kodi-MoinuTV-PrivatePlayer/1.0"

SECTIONS = [
    ("c01", "🎬 Movies"),
    ("c02", "📺 Web Series"),
    ("c03", "🎵 Songs & Theme Videos")
]

def fetch_data(chunk_id):
    url = f"{REPO_RAW}/data_{chunk_id}.json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Cache-Control": "no-cache"})
        with urllib.request.urlopen(req, timeout=12) as res:
            return json.loads(res.read().decode("utf-8"))
    except Exception as e:
        xbmc.log(f"[MoinuFlix] Fetch Error: {e}", xbmc.LOGERROR)
        return []

def list_categories():
    xbmcplugin.setContent(HANDLE, "files")
    for chunk_id, title in SECTIONS:
        li = xbmcgui.ListItem(label=title)
        url = f"{sys.argv[0]}?action=view_section&id={chunk_id}"
        xbmcplugin.addDirectoryItem(handle=HANDLE, url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def list_items(chunk_id):
    xbmcplugin.setContent(HANDLE, "movies")
    items = fetch_data(chunk_id)

    if not items:
        dialog = xbmcgui.Dialog()
        dialog.notification("MoinuFlix", "Catalog offline ya empty!", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(HANDLE, succeeded=False)
        return

    for item in items:
        title = item.get("display_name") or item.get("title") or item.get("name") or "Unknown"
        if item.get("season") and item.get("episode"):
            title = f"{item.get('show_title')} S{item.get('season'):02d}E{item.get('episode'):02d} - {item.get('episode_title', '')}"

        stream_url = item.get("stream_url")
        if not stream_url and item.get("id"):
            stream_url = f"https://gdrive-stream.moinudeentv.workers.dev/?id={item.get('id')}|User-Agent={USER_AGENT}"

        if not stream_url:
            continue

        li = xbmcgui.ListItem(label=title)
        poster = item.get("poster") or ""
        fanart = item.get("fanart") or poster
        logo = item.get("logo") or ""

        li.setArt({
            "thumb": poster,
            "poster": poster,
            "fanart": fanart,
            "clearlogo": logo,
            "icon": poster
        })

        rating_val = 0.0
        try:
            if item.get("rating"):
                rating_val = float(item.get("rating"))
        except:
            pass

        year_val = None
        try:
            if item.get("year") and str(item.get("year")).isdigit():
                year_val = int(item.get("year"))
        except:
            pass

        specs = item.get("specs", {})
        plot = item.get("plot", "")
        if specs:
            plot = f"[{specs.get('resolution', '')} | {specs.get('audio', '')} {specs.get('channels', '')}]\n\n{plot}"

        info = {
            "title": title,
            "plot": plot,
            "rating": rating_val,
            "year": year_val,
            "trailer": item.get("trailer") or "",
            "mediatype": "movie" if chunk_id != "c02" else "episode"
        }
        li.setInfo("video", info)
        li.setProperty("IsPlayable", "true")

        xbmcplugin.addDirectoryItem(handle=HANDLE, url=stream_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(HANDLE, succeeded=True)

def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:])) if len(sys.argv) > 2 else {}
    action = params.get("action")

    if action == "view_section":
        list_items(params.get("id", "c01"))
    else:
        list_categories()

if __name__ == "__main__":
    main()
